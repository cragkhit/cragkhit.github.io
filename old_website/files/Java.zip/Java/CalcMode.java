import java.io.*;
import java.util.*;
import java.lang.*;
 
 
class CalcMode
{
 
      public static void main(String[] args)
      {
 
            String inpstring = "";
            InputStreamReader input = new InputStreamReader(System.in);
            BufferedReader reader = new BufferedReader(input);
           
            try
            {
                  System.out.print("Enter a Number Elements to calculate Median:");
                  inpstring = reader.readLine();
 
                  long max = Long.parseLong(inpstring);
                  long[] arrElements = new long[100];
                  for (int i = 0; i < max; i++)
                  {
                        System.out.print("Enter [" + (i + 1) + "] Element: ");
                        inpstring = reader.readLine();
                        arrElements[i] = Long.parseLong(inpstring);
                  }
 
                  Map<Long, Integer> mymap = new HashMap<Long, Integer>();
 
                  for (int i = 0; i < max; i++)
                  {
                        if (mymap.containsKey(arrElements[i]) == false)
                              mymap.put(arrElements[i], 1);
                        else
                        {
                              int value = mymap.get(arrElements[i]);
                              mymap.put(arrElements[i], value + 1);
                        }
                  }
 
                  Set<Long> keyset = mymap.keySet();
                  Iterator it = keyset.iterator();
                  int maxcount = 0;
                  while(it.hasNext())
                  {
                        long key = Long.parseLong(it.next().toString());
                        int value = mymap.get(key);
                        System.out.println(key + " = " + value);
                        if (value > maxcount)
                              maxcount = value;
                  }
 
                  System.out.print("Mode: ");
                  it = keyset.iterator();
                  while (it.hasNext())
                  {
                        long key = Long.parseLong(it.next().toString());
                        int value = mymap.get(key);
                        if (value == maxcount)
                              System.out.print(key + " ");
                  }
            }
            catch (Exception e)
            {
                  e.printStackTrace();
            }
      }
}