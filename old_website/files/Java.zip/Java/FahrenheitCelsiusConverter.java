class FahrenheitCelsiusConverter { 
 
    public static void main(String[] args) {
 
            String inpstring = "";
            InputStreamReader input = new InputStreamReader(System.in);
            BufferedReader reader = new BufferedReader(input);
 
            try
            {
                  System.out.print("Enter a number to use in Fahrenheit and Celsius Converter:");
                  inpstring = reader.readLine();
                  double val = Double.parseDouble(inpstring);
 
                  double Celsius = (val - 32.0) * 5.0 / 9.0;
                  double Fahrenheit = (val * (9.0 / 5.0) + 32);
 
                  char degree = 248;
 
                  System.out.print(val);
                  System.out.print(degree);
                  System.out.print("F = ");
                  System.out.print(Celsius);
                  System.out.print(degree);
                  System.out.print("C\n");
 
                  System.out.print(val);
                  System.out.print(degree);
                  System.out.print("C = ");
                  System.out.print(Fahrenheit);
                  System.out.print(degree);
                  System.out.print("F\n");
 
            }
            catch (Exception e)
            {
                  e.printStackTrace();
            }
    }
}