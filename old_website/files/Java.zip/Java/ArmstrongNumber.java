import java.lang.*;
import java.util.*;
import java.io.*;
 
 
class ArmstrongNumber
{
   public static void main(String[] args)
   {     
      System.out.println("List of Armstrong Numbers between (100 - 999):");
 
      for(int i = 100; i <= 999; i++)
      {
         int a = i / 100;
         int b = (i - a * 100) / 10;
         int c = (i - a * 100 - b * 10);
 
         int d = a*a*a + b*b*b + c*c*c;
 
         if(i == d)
            System.out.format("%d\n", i); 
      }
   }
}
