import java.lang.*;
import java.util.*;
import java.io.*;
 
 
class Check_ODD_EVEN
{
 
    public static int ReadInteger()
   {
        try
        {
              InputStreamReader input = new InputStreamReader(System.in);
              BufferedReader reader = new BufferedReader(input);
              return Integer.parseInt(reader.readLine());
        }
        catch (Exception e)
        {
 
              e.printStackTrace();
              return 0;
        }
   }
  
   public static void main(String[] args)
   {
         System.out.print("Enter a Number to Check ODD or EVEN: ");
         int number = ReadInteger();
 
         if((number % 2) == 0)
            System.out.format("%d is an EVEN number\n", number);
         else
            System.out.format("%d is an ODD number\n", number);       
   }
}