import java.io.*;
 
 
class CalcMean {
 
    public static void main(String[] args) {
 
            String inpstring = "";
            InputStreamReader input = new InputStreamReader(System.in);
            BufferedReader reader = new BufferedReader(input);
 
            try
            {
                  System.out.print("Enter a Number Elements to calculate Mean:");
                  inpstring = reader.readLine();
 
                  long max = Long.parseLong(inpstring);
                  long[] arrElements = new long[100];
                  for (int i = 0; i < max; i++)
                  {
                        System.out.print("Enter [" + (i + 1) + "] Element: ");
                        inpstring = reader.readLine();
                        arrElements[i] = Long.parseLong(inpstring);
                  }
 
                  double total = 0;
                  for(int i = 0; i < max; i++)
                  {
                        total += arrElements[i];
                  }
 
                  double mean = total / max;
 
                  System.out.println("Mean: " + mean);
            }
            catch (Exception e)
            {
                  e.printStackTrace();
            }
    }
}