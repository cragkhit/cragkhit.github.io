import java.lang.*;
import java.util.*;
import java.io.*;
 
 
class StringToNumber
{
      static int StringToNumber(String str)
      {
         int result = 0;
         int startIndex = 0;
         int negativeNumber = 0;
        
         char[] buffer = str.toCharArray();
 
         if(buffer[0] == '-')
         {
               negativeNumber = 1;
               startIndex = 1;
         }
         for(int i = startIndex; i < buffer.length; i++)
         {
            if(buffer[i] >= '0' && buffer[i] <= '9')
            {
               int digit = buffer[i] - '0';
               result = result * 10 + digit;
            }
            else
               return 0;
         }
         if(negativeNumber == 1)
            result *= -1;
         return result;
      }
     
      static public String ReadString()
      {
            try
            {
                  String inpString = "";
                  InputStreamReader input = new InputStreamReader(System.in);
                  BufferedReader reader = new BufferedReader(input);
                  return reader.readLine();
            }
            catch (Exception e)
            {
                  e.printStackTrace();
            }
            return "";
      }
 
 
 
      public static void main(String[] args)
      { 
         System.out.println("String to Number Conversion Program");
 
         while(true)
         {
            System.out.print("Enter a String (-1 to exit): ");
            String s = ReadString();
           
            int number = StringToNumber(s);
 
            System.out.println("Converted Number: " + number);
 
            if(number == -1)
               break;
         }
      }
}