import java.lang.*;
import java.util.*;
import java.io.*;
 
 
class BreakContinue
{
   public static void main(String[] args)
   {    
      int evencount = 0, i = 0;
      for(i = 0; ; i++)
      {
          if(i >= 60)
              break; // Terminate the for loop
 
          if((i % 2) != 0)
              continue; // Will skip the reminder of the for loop
 
          evencount++;
      }
      System.out.format("Total Even Numbers Between 0 to 60 is: %d", evencount);
 
   }
}