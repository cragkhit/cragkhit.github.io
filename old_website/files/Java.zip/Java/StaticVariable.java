import java.io.*;
 
 
class StaticVariable
{
    public static void CountNumberOfTimes()
    {
        static int counter = 0;
        counter++;
        System.out.println(counter);
    }
 
    public static void main(String[] args)
    { 
        System.out.println("\n\nProgram for explaining Static Variables Concept: \n");
 
        for(int i = 0; i < 5; i++)
         CountNumberOfTimes();
       
 
        System.out.println("\n");
    }
}