import java.io.*;
 
 
class Palindrome {     
 
    public static void main(String[] args) {
 
            String inpstring = "";
            InputStreamReader input = new InputStreamReader(System.in);
            BufferedReader reader = new BufferedReader(input);
 
            try
            {
                  System.out.print("Enter a string to check Palindrome:");
                  inpstring = reader.readLine();
 
                  int len = inpstring.length();
                  inpstring = inpstring.toUpperCase();
                  boolean bPalindrome = true;
 
                  for (int i = 0; i < (len / 2 + 1); i++)
                  {
                        if (inpstring.charAt(i) != inpstring.charAt(len - i - 1))
                        {
                              bPalindrome = false;
                        }
                  }
                  if(bPalindrome == true)
                        System.out.println(inpstring + " is a palindrome");
                  else
                        System.out.println(inpstring + " is NOT a palindrome");
            }
            catch (Exception e)
            {
                  e.printStackTrace();
            }
    }
}