import java.io.*;
 
 
class StringReverse {  
 
    public static void main(String[] args) {
 
            String inpstring = "";
            InputStreamReader input = new InputStreamReader(System.in);
            BufferedReader reader = new BufferedReader(input);
 
            try
            {
                  System.out.print("Enter a string to reverse:");
                  inpstring = reader.readLine();
 
                  int len = inpstring.length();
                  int lastindex = len - 1;
 
                  char[] outstring = inpstring.toCharArray();
 
                  int l = (len / 2);
 
                  if( (len % 2) == 1)
                        l++;
 
                  for (int i = 0; i < l; i++)
                  {
                        char ch = outstring[i];
                        outstring[i] = outstring[lastindex];
                        outstring[lastindex] = ch;
                        lastindex--;
                  }
 
                  System.out.print(inpstring + " => ");
                  for (int k = 0; k < outstring.length; k++)
                  {
                        System.out.print(outstring[k]);
                  }
                  System.out.println();
            }
            catch (Exception e)
            {
                  e.printStackTrace();
            }
    }
}