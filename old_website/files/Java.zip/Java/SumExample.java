import java.lang.*;
import java.util.*;
import java.io.*;
 
 
class SumExample
{
   public static void main(String[] args)
   {     
      int sum = 0;
      int i, a, b, c;
      for(i = 100; i <= 200; i++)
      {
         a = i % 100;
         b = a / 10;
         c = a % 10;
         if(b == 5 || c == 5)
            System.out.format("%d\n", i);
         sum += i;
      }
      System.out.format("\n\nSum = %d\n\n", sum);
   }
}