import java.io.*;
 
 
class Shape
{
 
    public Shape()
    {
        System.out.println("Shape");
    }
 
    static public void draw()
    {
        System.out.println("Drawing Shape");
    }
}
 
 
class StaticFunction
{
    public static void main(String[] args)
    {
        Shape object = new Shape();
 
        System.out.println("\n\nNow Drawing Objects\n");
 
        // object.draw(); // It is not a good practice to use this syntax even if it works.
        Shape.draw(); // It is the correct usage of calling static function.
         
        System.out.println("\n");
    }
}