import java.lang.*;
import java.util.*;
import java.io.*;
 
 
class FunctionCount
{
   static int count = 0; 
  
   public static void TestFunction()
   {
         System.out.format("Number of times called: %d\n", ++count);
   }
  
   public static void main(String[] args)
   {
         for (int i = 0; i < 5; i++)
            TestFunction();
   }
}