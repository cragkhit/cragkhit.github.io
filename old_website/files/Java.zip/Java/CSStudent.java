import java.io.*;
import java.lang.*;
import java.util.*;
import java.text.*;
 
class CStudent
{
      private String name;
      private int age;
      private String addr1;
      private String addr2;
      private String city;
      private String zipcode;
 
      public CStudent() { }
 
      public String GetName() { return name; }
      public String GetAddr1() { return addr1; }
      public String GetAddr2() { return addr2; }
      public String GetCity() { return city; }
      public String GetZipCode() { return zipcode; }
      public int GetAge() { return age; }
 
      public void SetName(String s) { name = s; }
      public void SetAddr1(String s) { addr1 = s; }
      public void SetAddr2(String s) { addr2 = s; }
      public void SetCity(String s) { city = s; }
      public void SetZipCode(String s) { zipcode = s; }
      public void GetAge(int v) { age = v; }
};
 
class DataHiding
{
      static public void main(String[] args)
      {
            CStudent s = new CStudent();
 
            // s.name = "softwareandfinance.com"; // Not allowed, compiler error name has private access in CStudent
            // System.out.print(s.name);
 
            s.SetName("softwareandfinance.com");
            System.out.print(s.GetName());           
      }
}