import java.io.*;
 
 
class ReadAndDisplayString { 
 
    public static void main(String[] args) {
 
            String inpstring = "";
            InputStreamReader input = new InputStreamReader(System.in);
            BufferedReader reader = new BufferedReader(input);
 
            try
            {
                  System.out.print ("Enter a String:");
                  inpstring = reader.readLine();
                  System.out.println(inpstring.toString());
            }
            catch (Exception e)
            {
                  e.printStackTrace();
            }
    }
}
 