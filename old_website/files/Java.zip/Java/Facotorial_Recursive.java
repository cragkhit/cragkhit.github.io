import java.io.*;
 
 
class Facotorial_Recursive {
 
      public static long Fact(long n)
      {
            if (n <= 1)
                  return n;
            return n * Fact(n - 1);
      }
 
    public static void main(String[] args) {
 
            String inpstring = "";
            InputStreamReader input = new InputStreamReader(System.in);
            BufferedReader reader = new BufferedReader(input);
 
            try
            {
                  System.out.print("Enter a Number to Find Factorial:");
                  inpstring = reader.readLine();
 
                  long n = Long.parseLong(inpstring);
 
                  long result = Fact(n);
                 
                  System.out.println("Facorial of " + n + " is " + result);
            }
            catch (Exception e)
            {
                  e.printStackTrace();
            }
    }
}
 