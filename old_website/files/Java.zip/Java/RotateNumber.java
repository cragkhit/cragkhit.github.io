import java.io.*;
import java.lang.*;
 
 
class RotateNumber {   
 
 
      public static void RotateNumber(long number)
      {
            long start = number;
 
            int numdigits = (int) Math.log10((double)number); // would return numdigits - 1
            int multiplier = (int) Math.pow(10.0, (double)numdigits);
 
            //System.out.println(numdigits);
            //System.out.println(multiplier);
           
            while(true)
            {
                  long q = number / 10;
                  long r = number % 10;
 
                  //1234 = 123;
                  number = number / 10;
                  number = number + multiplier * r;
 
                  System.out.println(number);
                 
                  if(number == start)
                        break;
            }
      }
 
 
    public static void main(String[] args) {
 
            String inpstring = "";
            InputStreamReader input = new InputStreamReader(System.in);
            BufferedReader reader = new BufferedReader(input);
 
            try
            {
                  System.out.println("Enter a Number to Rotate:");
                  inpstring = reader.readLine();
                  long number = Long.parseLong(inpstring, 10);
                  RotateNumber(number);
            }
            catch (Exception e)
            {
                  e.printStackTrace();
            }
    }
}