import java.lang.*;
import java.util.*;
import java.util.List;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
 
   public class MyDrawPixel extends Frame {
 
     public Point mypoint = new Point();       
     public static void drawPixel(Graphics g, int x, int y, int size, Paint color) 
     {
         Graphics2D ga = (Graphics2D)g;
         Shape circle = new Ellipse2D.Float(x, y, size, size);    
         ga.setPaint(color);
         ga.draw(circle);
         ga.setPaint(color);
         ga.fill(circle);
     }
 
     public void paint(Graphics g) {
        Graphics2D ga = (Graphics2D)g;
        drawPixel(g, mypoint.x, mypoint.y, 3, Color.blue);
     }
      
      
      
   public static int ReadInteger()
   {
        try
        {
              InputStreamReader input = new InputStreamReader(System.in);
              BufferedReader reader = new BufferedReader(input);
              return Integer.parseInt(reader.readLine());
        }
        catch (Exception e)
        {
 
              e.printStackTrace();
              return 0;
        }
   }
       
       
          
  public static void main(String args[]) 
  {     
      System.out.format("Enter Point X: ");
      int x = ReadInteger();
      System.out.format("Enter Point Y: ");
      int y = ReadInteger();
 
      MyDrawPixel frame = new MyDrawPixel();     
      frame.mypoint.x = x;
      frame.mypoint.y = y;
                 
      frame.addWindowListener(
      new WindowAdapter()
      {
         public void windowClosing(WindowEvent we)
         {
            System.exit(0);
         }
      }
      );
           
      frame.setSize(400, 400);
      frame.setVisible(true);
   }
}