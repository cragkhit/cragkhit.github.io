import java.lang.*;
import java.util.*;
import java.util.List;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
 
public class FillRectangle extends Frame {
 
  public void paint(Graphics g) {
     Graphics2D ga = (Graphics2D)g;
     ga.setPaint(Color.red);
     ga.fillRect(50,50,300,300);
     ga.setPaint(Color.green);
     ga.fillRect(100,100,200,200);
     ga.setPaint(Color.blue);
     ga.fillRect(150,150,100,100);          
  }
               
  public static void main(String args[]) 
  {
      FillRectangle frame = new FillRectangle();       
      frame.addWindowListener(
      new WindowAdapter()
      {
         public void windowClosing(WindowEvent we)
         {
            System.exit(0);
         }
      }
      );
            
      frame.setSize(400, 400);
      frame.setVisible(true);
   }
}