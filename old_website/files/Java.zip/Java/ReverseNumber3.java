import java.io.*;
 
 
class ReverseNumber {  
 
 
      public static long ReverseInt(long number)
      {
            int result = 0;
            int msbpos = 4 * 8 - 1;
 
            while(true)
            {
                  if( (number & 0x01) == 1)
                  {
                        result |= (0x01 << msbpos);
                  }
                  number >>= 1;
                  msbpos--;
                  if(msbpos < 0)
                        break;
            }
            return result;
      }
 
 
    public static void main(String[] args) {
 
            String inpstring = "";
            InputStreamReader input = new InputStreamReader(System.in);
            BufferedReader reader = new BufferedReader(input);
 
            try
            {
                  System.out.print("Enter a Number to reverse its bits:");
                  inpstring = reader.readLine();
                  long number = Long.parseLong(inpstring, 16);
                  long rnumber = ReverseInt(number);
                  System.out.println(Long.toString(number, 2) + "\n" + Long.toString(rnumber, 2));
                  System.out.println(Long.toString(number, 16) + "\n" + Long.toString(rnumber, 16));
            }
            catch (Exception e)
            {
                  e.printStackTrace();
            }
    }
}