import java.lang.*;
import java.util.*;
import java.util.List;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
 
public class RotateEllipse extends Frame {
 
  public void paint(Graphics g) {
     Graphics2D ga = (Graphics2D)g;
 
     for (int angle = 0; angle <= 360; angle += 45) {
        ga.rotate(Math.toRadians(angle), 200, 150);
        ga.setPaint(Color.blue);
        ga.fillArc(100,100,200,100, 0, 360);
     }
      
     for (int angle = 0; angle <= 360; angle += 45) {
        ga.rotate(Math.toRadians(angle), 200, 150);
        ga.setPaint(Color.white);
     ga.drawArc(100,100,200,100, 0, 360);
     }
  }
               
  public static void main(String args[]) 
  {
      RotateEllipse frame = new RotateEllipse();       
      frame.addWindowListener(
      new WindowAdapter()
      {
         public void windowClosing(WindowEvent we)
         {
            System.exit(0);
         }
      }
      );
            
      frame.setSize(400, 400);
      frame.setVisible(true);
   }
}