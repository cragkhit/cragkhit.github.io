import java.lang.*;
import java.util.*;
import java.io.*;
 
 
class LowerToUpper
{
      public static String ReadString()
      {
           try
           {
                 InputStreamReader input = new InputStreamReader(System.in);
                 BufferedReader reader = new BufferedReader(input);
                 return reader.readLine();
           }
           catch (Exception e)
           {
 
                 e.printStackTrace();
                 return "";
           }
      }
 
 
      public static int ReadInteger()
      {
           try
           {
                 InputStreamReader input = new InputStreamReader(System.in);
                 BufferedReader reader = new BufferedReader(input);
                 return Integer.parseInt(reader.readLine());
           }
           catch (Exception e)
           {
 
                 e.printStackTrace();
                 return 0;
           }
      }
 
      public static String ConvertToUpperCase(String input)
      {
           String output = "";
           for(int i = 0; i < input.length(); i++)
           {
                 if(input.charAt(i) >= 'a' && input.charAt(i) <= 'z')
                 {
                      output += (char) (input.charAt(i) - 'a' + 'A');
                 }
                 else
                      output += input.charAt(i);
           }
           return output;
      }
 
      public static void main(String[] args)
      {
           System.out.print("Enter a string: ");
           String input = ReadString();
           //input = input.toUpperCase();
           input = ConvertToUpperCase(input);
           System.out.print("Converted String in Upper Case: " + input);
      }
}