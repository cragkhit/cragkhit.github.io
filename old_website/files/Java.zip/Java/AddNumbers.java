import java.io.*;
 
 
class AddNumbers {     
 
    public static void main(String[] args) {
 
            String inpstring = "";
            InputStreamReader input = new InputStreamReader(System.in);
            BufferedReader reader = new BufferedReader(input);
 
            try
            {
                  System.out.println("Program for Adding Two Numbers");
                  System.out.print("Enter First Number:");
                  inpstring = reader.readLine();
                  int a = Integer.parseInt(inpstring);
                  System.out.print("Enter Second Number:");
                  inpstring = reader.readLine();
                  int b = Integer.parseInt(inpstring);
                  System.out.println("Result: " + (a + b));
            }
            catch (Exception e)
            {
                  e.printStackTrace();
            }
    }
}