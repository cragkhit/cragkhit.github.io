import java.io.*;
import java.lang.*;
 
 
class Pattern {  
 
    public static void main(String[] args) {
 
            String inpstring = "";
            InputStreamReader input = new InputStreamReader(System.in);
            BufferedReader reader = new BufferedReader(input);
 
            try
            {
                  System.out.print("Enter a Number to build pattern:");
                  inpstring = reader.readLine();
                  int n = Integer.parseInt(inpstring, 10);
 
                  for(int i = n; i > 1; i--)
                  {
                        for(int j = 1; j <= i; j++)
                              System.out.print("*");
                        System.out.println();
                  }
 
                  for(int i = 1; i <= n; i++)
                  {
                        for(int j = 1; j <= i; j++)
                              System.out.print("*");
                        System.out.println();
                  }
                  System.out.println();
 
                  for(int i = 1; i < n; i++)
                  {
                        for(int j = 1; j <= i; j++)
                              System.out.print(j);
                        System.out.println();
                  }
 
                  for (int i = n; i >= 0; i--)
                  {
                        for (int j = 1; j <= i; j++)
                              System.out.print(j);
                        System.out.println();
                  }
                  System.out.println();
            }
            catch (Exception e)
            {
                  e.printStackTrace();
            }
    }
}