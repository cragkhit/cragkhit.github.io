import java.io.*;
 
 
class Facotorial_NoRecursive {
 
      public static long Fact(long n)
      {
            long result = 1;
            for (int i = 1; i <= n; i++)
                  result = result * i;
            return result;
      }
 
    public static void main(String[] args) {
 
            String inpstring = "";
            InputStreamReader input = new InputStreamReader(System.in);
            BufferedReader reader = new BufferedReader(input);
 
            try
            {
                  System.out.print("Enter a Number to Find Factorial:");
                  inpstring = reader.readLine();
 
                  long n = Long.parseLong(inpstring);
 
                  long result = Fact(n);
                 
                  System.out.println("Facorial of " + n + " is " + result);
            }
            catch (Exception e)
            {
                  e.printStackTrace();
            }
    }
}