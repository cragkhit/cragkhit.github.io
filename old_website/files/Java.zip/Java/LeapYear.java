import java.io.*;
 
 
class LeapYear {
 
 
      public static boolean IsLeapYear(int year)
      {
            if ((year % 4) == 0)
            {
                  if ((year % 100) == 0)
                  {
                        if ((year % 400) == 0)
                              return true;
                        else
                              return false;
                  }
                  else
                        return true;
            }
            return false;
      }
 
 
 
    public static void main(String[] args) {
 
            String inpstring = "";
            InputStreamReader input = new InputStreamReader(System.in);
            BufferedReader reader = new BufferedReader(input);
 
            try
            {
                  System.out.print("Enter the Year to check Leap Year: ");
                  inpstring = reader.readLine();
 
                  int year = Integer.parseInt(inpstring);
                 
                 
                  if(IsLeapYear(year) == true)
                        System.out.println(year + " is a Leap Year");
                  else
                        System.out.println(year + " is NOT a Leap Year");
            }
            catch (Exception e)
            {
                  e.printStackTrace();
            }
    }
}