import java.lang.*;
import java.util.*;
import java.util.List;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
 
public class ScalePolygon extends Frame {
 
  public Polygon mypolygon = new Polygon();
  public Polygon mypolygon2 = new Polygon();
     
  public void paint(Graphics g) {
     Graphics2D ga = (Graphics2D)g;
     ga.setPaint(Color.red);
     ga.draw(mypolygon);
     ga.setPaint(Color.green);
     /***
     AffineTransform defaultTransformation = ga.getTransform();
     AffineTransform newscaleTransformation = new AffineTransform();
     newscaleTransformation.scale(2, 2);
     ga.setTransform(newscaleTransformation);
     ***/
     ga.draw(mypolygon2);
  }
   
   public static int ReadInteger()
   {
        try
        {
              InputStreamReader input = new InputStreamReader(System.in);
              BufferedReader reader = new BufferedReader(input);
              return Integer.parseInt(reader.readLine());
        }
        catch (Exception e)
        {
 
              e.printStackTrace();
              return 0;
        }
   }
    
   public static List< Integer > ScaleTranform(List< Integer > srcpoints, double x, double y)
   {
     AffineTransform newscaleTransformation = new AffineTransform();
     double[] src = new double[100];
     double[] dest = new double[100];
     for(int i = 0; i < srcpoints.size(); i++)
         src[i] = srcpoints.get(i);
     newscaleTransformation.scale(2, 2);
     newscaleTransformation.translate(-src[0] * 0.62,-src[1] * 0.5);
     newscaleTransformation.transform(src,0,dest,0,srcpoints.size() / 2);
      
     List< Integer > destpoints = new ArrayList< Integer >();
     for(int i = 0; i < srcpoints.size(); i++)
      destpoints.add((int) dest[i]);
     return destpoints;
   }
       
  public static void main(String args[]) {
     List< Integer > srcpoints = new ArrayList< Integer >();
     /***
     System.out.format("Enter Number of points: ");
     int n = ReadInteger();
     for(int i = 0; i < n; i++)
     {
         System.out.format("Enter x[%d]: ", i + 1);
         srcpoints.add(ReadInteger());
         System.out.format("Enter y[%d]: ", i + 1);
         srcpoints.add(ReadInteger());
     }
     ***/
     srcpoints.add(100);srcpoints.add(100);
     srcpoints.add(75);srcpoints.add(75);
     srcpoints.add(150);srcpoints.add(100);
     srcpoints.add(75);srcpoints.add(125);
     srcpoints.add(srcpoints.get(0));
     srcpoints.add(srcpoints.get(1));
      
     ScalePolygon frame = new ScalePolygon();
     for(int i = 0; i < srcpoints.size(); i++)
     {
         int x = srcpoints.get(i++);
         int y = srcpoints.get(i);
         frame.mypolygon.addPoint(x, y);
     }
      
     List< Integer > destpoints = ScaleTranform(srcpoints, 2, 2);
      
     for(int i = 0; i < destpoints.size(); i++)
     {
         int x = destpoints.get(i++);
         int y = destpoints.get(i);
         frame.mypolygon2.addPoint(x, y);
     }
      
      
     frame.addWindowListener(
      new WindowAdapter()
      {
         public void windowClosing(WindowEvent we)
         {
            System.exit(0);
         }
      }
     );
      
   frame.setSize(400, 400);
   frame.setVisible(true);
  }
}
 
/***
      Enter Number of points: 4
      Enter x[1]: 100
      Enter y[1]: 100
      Enter x[2]: 150
      Enter y[2]: 100
      Enter x[3]: 150
      Enter y[3]: 150
      Enter x[4]: 100
      Enter y[4]: 150
***/