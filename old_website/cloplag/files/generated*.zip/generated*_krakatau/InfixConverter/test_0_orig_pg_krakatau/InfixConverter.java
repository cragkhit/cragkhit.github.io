class InfixConverter {
    InfixConverter() {
        super();
    }
    private static String a ( String s ) {
        java.util.Stack a = new java.util.Stack();
        String s0 = "";
        int i = 0;
        while ( i < s.length() ) {
            String s1 = null;
            int i0 = 0;
            int i1 = s.charAt ( i );
            label0: {
                int i2 = 0;
                label11: {
                    label15: {
                        if ( i1 != 43 ) {
                            break label15;
                        }
                        i2 = 43;
                        break label11;
                    }
                    label14: {
                        if ( i1 != 45 ) {
                            break label14;
                        }
                        i2 = 45;
                        break label11;
                    }
                    label13: {
                        if ( i1 != 42 ) {
                            break label13;
                        }
                        i2 = 42;
                        break label11;
                    }
                    label12: {
                        if ( i1 != 47 ) {
                            break label12;
                        }
                        i2 = 47;
                        break label11;
                    }
                    StringBuilder a0 = new StringBuilder().append ( s0 );
                    int i3 = ( char ) i1;
                    s1 = a0.append ( ( char ) i3 ).toString();
                    i0 = i;
                    break label0;
                }
                if ( a.size() <= 0 ) {
                    int i4 = ( char ) i2;
                    a.push ( ( Object ) Character.valueOf ( ( char ) i4 ) );
                    s1 = s0;
                    i0 = i;
                } else {
                    int i5 = 0;
                    Character a1 = ( Character ) a.peek();
                    int i6 = a1.charValue();
                    label7: {
                        label8: {
                            label9: {
                                label10: {
                                    if ( i6 != 42 ) {
                                        break label10;
                                    }
                                    break label9;
                                }
                                int i7 = a1.charValue();
                                if ( i7 != 47 ) {
                                    break label8;
                                }
                            }
                            i5 = 1;
                            break label7;
                        }
                        i5 = 0;
                    }
                    label1: {
                        label2: {
                            {
                                String s2 = null;
                                int i8 = 0;
                                label5: {
                                    int i9 = 0;
                                    label6: {
                                        if ( i5 != 1 ) {
                                            break label6;
                                        }
                                        if ( i2 == 43 ) {
                                            break label1;
                                        }
                                        if ( i2 == 45 ) {
                                            break label1;
                                        }
                                        String s3 = new StringBuilder().append ( s0 ).append ( a.pop() ).toString();
                                        int i10 = i + -1;
                                        s2 = s3;
                                        i8 = i10;
                                        break label5;
                                    }
                                    label3: {
                                        label4: {
                                            if ( i2 != 43 ) {
                                                break label4;
                                            }
                                            i9 = 43;
                                            break label3;
                                        }
                                        if ( i2 != 45 ) {
                                            break label2;
                                        }
                                        i9 = 45;
                                    }
                                    String s4 = new StringBuilder().append ( s0 ).append ( a.pop() ).toString();
                                    int i11 = ( char ) i9;
                                    a.push ( ( Object ) Character.valueOf ( ( char ) i11 ) );
                                    s2 = s4;
                                    i8 = i;
                                }
                                s1 = s2;
                                i0 = i8;
                                break label0;
                            }
                            break label1;
                        }
                        int i12 = ( char ) i2;
                        a.push ( ( Object ) Character.valueOf ( ( char ) i12 ) );
                        s1 = s0;
                        i0 = i;
                        break label0;
                    }
                    String s5 = new StringBuilder().append ( s0 ).append ( a.pop() ).toString();
                    int i13 = i + -1;
                    s1 = s5;
                    i0 = i13;
                }
            }
            int i14 = i0 + 1;
            s0 = s1;
            i = i14;
        }
        int i15 = a.size();
        String s6 = s0;
        int i16 = 0;
        while ( i16 < i15 ) {
            String s7 = new StringBuilder().append ( s6 ).append ( a.pop() ).toString();
            int i17 = i16 + 1;
            s6 = s7;
            i16 = i17;
        }
        return s6;
    }
    public static void main ( String[] a ) {
        if ( a.length == 1 ) {
            String s = a[0];
            String s0 = InfixConverter.a ( s );
            System.out.println ( new StringBuilder ( "InFix  :\t" ).append ( s ).toString() );
            System.out.println ( new StringBuilder ( "PostFix:\t" ).append ( s0 ).toString() );
            System.out.println();
            return;
        } else {
            String s1 = InfixConverter.a ( "a+b*c" );
            System.out.println ( new StringBuilder ( "InFix  :\t" ).append ( "a+b*c" ).toString() );
            System.out.println ( new StringBuilder ( "PostFix:\t" ).append ( s1 ).toString() );
            System.out.println();
            String s2 = InfixConverter.a ( "a+b*c/d-e" );
            System.out.println ( new StringBuilder ( "InFix  :\t" ).append ( "a+b*c/d-e" ).toString() );
            System.out.println ( new StringBuilder ( "PostFix:\t" ).append ( s2 ).toString() );
            System.out.println();
            String s3 = InfixConverter.a ( "a+b*c/d-e+f*h/i+j-k" );
            System.out.println ( new StringBuilder ( "InFix  :\t" ).append ( "a+b*c/d-e+f*h/i+j-k" ).toString() );
            System.out.println ( new StringBuilder ( "PostFix:\t" ).append ( s3 ).toString() );
            System.out.println();
            return;
        }
    }
}
