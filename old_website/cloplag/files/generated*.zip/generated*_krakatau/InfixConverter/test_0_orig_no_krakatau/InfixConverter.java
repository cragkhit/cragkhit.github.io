class InfixConverter {
    InfixConverter() {
        super();
    }
    public static String ReadString() {
        String s = null;
        try {
            s = new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( System.in ) ).readLine();
        } catch ( Exception a ) {
            a.printStackTrace();
            return "";
        }
        return s;
    }
    public static int ReadInteger() {
        int i = 0;
        try {
            i = Integer.parseInt ( new java.io.BufferedReader ( ( java.io.Reader ) new java.io.InputStreamReader ( System.in ) ).readLine() );
        } catch ( Exception a ) {
            a.printStackTrace();
            return 0;
        }
        return i;
    }
    public static String InfixToPostfixConvert ( String s ) {
        java.util.Stack a = new java.util.Stack();
        String s0 = "";
        int i = 0;
        while ( i < s.length() ) {
            String s1 = null;
            int i0 = 0;
            int i1 = s.charAt ( i );
            label11: {
                int i2 = 0;
                label12: {
                    label16: {
                        if ( i1 != 43 ) {
                            break label16;
                        }
                        i2 = 43;
                        break label12;
                    }
                    label15: {
                        if ( i1 != 45 ) {
                            break label15;
                        }
                        i2 = 45;
                        break label12;
                    }
                    label14: {
                        if ( i1 != 42 ) {
                            break label14;
                        }
                        i2 = 42;
                        break label12;
                    }
                    label13: {
                        if ( i1 != 47 ) {
                            break label13;
                        }
                        i2 = 47;
                        break label12;
                    }
                    StringBuilder a0 = new StringBuilder().append ( s0 );
                    int i3 = ( char ) i1;
                    s1 = a0.append ( ( char ) i3 ).toString();
                    i0 = i;
                    break label11;
                }
                if ( a.size() <= 0 ) {
                    int i4 = ( char ) i2;
                    a.push ( ( Object ) Character.valueOf ( ( char ) i4 ) );
                    s1 = s0;
                    i0 = i;
                } else {
                    int i5 = 0;
                    String s2 = null;
                    int i6 = 0;
                    Character a1 = ( Character ) a.peek();
                    int i7 = a1.charValue();
                    label7: {
                        label8: {
                            label9: {
                                label10: {
                                    if ( i7 != 42 ) {
                                        break label10;
                                    }
                                    break label9;
                                }
                                int i8 = a1.charValue();
                                if ( i8 != 47 ) {
                                    break label8;
                                }
                            }
                            i5 = 1;
                            break label7;
                        }
                        i5 = 0;
                    }
                    label0: if ( i5 == 1 ) {
                        label4: {
                            label5: {
                                label6: {
                                    if ( i2 != 43 ) {
                                        break label6;
                                    }
                                    break label5;
                                }
                                if ( i2 != 45 ) {
                                    break label4;
                                }
                            }
                            String s3 = new StringBuilder().append ( s0 ).append ( a.pop() ).toString();
                            int i9 = i + -1;
                            s2 = s3;
                            i6 = i9;
                            break label0;
                        }
                        String s4 = new StringBuilder().append ( s0 ).append ( a.pop() ).toString();
                        int i10 = i + -1;
                        s2 = s4;
                        i6 = i10;
                    } else {
                        int i11 = 0;
                        label1: {
                            label3: {
                                if ( i2 != 43 ) {
                                    break label3;
                                }
                                i11 = 43;
                                break label1;
                            }
                            label2: {
                                if ( i2 != 45 ) {
                                    break label2;
                                }
                                i11 = 45;
                                break label1;
                            }
                            int i12 = ( char ) i2;
                            a.push ( ( Object ) Character.valueOf ( ( char ) i12 ) );
                            s2 = s0;
                            i6 = i;
                            break label0;
                        }
                        String s5 = new StringBuilder().append ( s0 ).append ( a.pop() ).toString();
                        int i13 = ( char ) i11;
                        a.push ( ( Object ) Character.valueOf ( ( char ) i13 ) );
                        s2 = s5;
                        i6 = i;
                    }
                    s1 = s2;
                    i0 = i6;
                }
            }
            int i14 = i0 + 1;
            s0 = s1;
            i = i14;
        }
        int i15 = a.size();
        String s6 = s0;
        int i16 = 0;
        while ( i16 < i15 ) {
            String s7 = new StringBuilder().append ( s6 ).append ( a.pop() ).toString();
            int i17 = i16 + 1;
            s6 = s7;
            i16 = i17;
        }
        return s6;
    }
    public static void main ( String[] a ) {
        if ( a.length == 1 ) {
            String s = a[0];
            String s0 = InfixConverter.InfixToPostfixConvert ( s );
            System.out.println ( new StringBuilder().append ( "InFix  :\t" ).append ( s ).toString() );
            System.out.println ( new StringBuilder().append ( "PostFix:\t" ).append ( s0 ).toString() );
            System.out.println();
        } else {
            String s1 = InfixConverter.InfixToPostfixConvert ( "a+b*c" );
            System.out.println ( new StringBuilder().append ( "InFix  :\t" ).append ( "a+b*c" ).toString() );
            System.out.println ( new StringBuilder().append ( "PostFix:\t" ).append ( s1 ).toString() );
            System.out.println();
            String s2 = InfixConverter.InfixToPostfixConvert ( "a+b*c/d-e" );
            System.out.println ( new StringBuilder().append ( "InFix  :\t" ).append ( "a+b*c/d-e" ).toString() );
            System.out.println ( new StringBuilder().append ( "PostFix:\t" ).append ( s2 ).toString() );
            System.out.println();
            String s3 = InfixConverter.InfixToPostfixConvert ( "a+b*c/d-e+f*h/i+j-k" );
            System.out.println ( new StringBuilder().append ( "InFix  :\t" ).append ( "a+b*c/d-e+f*h/i+j-k" ).toString() );
            System.out.println ( new StringBuilder().append ( "PostFix:\t" ).append ( s3 ).toString() );
            System.out.println();
        }
    }
}
