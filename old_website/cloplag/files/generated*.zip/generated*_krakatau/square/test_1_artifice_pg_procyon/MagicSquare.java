public class MagicSquare {
    private int[][] a;
    private boolean[] b;
    private int c;
    private int d;
    private int e;
    public static void main ( String[] a0 ) {
        MagicSquare a1 = new MagicSquare ( 3 );
        a1.a ( 0, 0 );
        System.out.println ( new StringBuilder().append ( "There were " ).append ( a1.e ).append ( " number of solutions." ).toString() );
    }
    private MagicSquare ( int i ) {
        super();
        this.a = new int[3][3];
        int i0 = 0;
        while ( i0 < 3 ) {
            int i1 = 0;
            while ( i1 < 3 ) {
                this.a[i0][i1] = 0;
                i1 = i1 + 1;
            }
            i0 = i0 + 1;
        }
        this.c = 9;
        this.b = new boolean[this.c];
        int i2 = 0;
        while ( i2 < this.c ) {
            this.b[i2] = true;
            i2 = i2 + 1;
        }
        this.d = 15;
        this.e = 0;
    }
    private void a ( int i, int i0 ) {
        while ( true ) {
            int i1 = 0;
            while ( i1 < this.a.length ) {
                int i2 = 0;
                int i3 = 0;
                int i4 = 0;
                while ( i4 < this.a[i1].length ) {
                    int i5 = i2 + this.a[i1][i4];
                    int i6 = ( this.a[i1][i4] != 0 ) ? i3 : 1;
                    int i7 = i4 + 1;
                    i2 = i5;
                    i3 = i6;
                    i4 = i7;
                }
                if ( i3 == 0 && i2 != this.d ) {
                    return;
                }
                i1 = i1 + 1;
            }
        }
    }
    public String toString() {
        String s = "";
        int i = 0;
        while ( i < this.a.length ) {
            String s0 = s;
            int i0 = 0;
            while ( i0 < this.a[i].length ) {
                String s1 = new StringBuilder().append ( s0 ).append ( 0 + this.a[i][i0] ).append ( "\t" ).toString();
                int i1 = i0 + 1;
                s0 = s1;
                i0 = i1;
            }
            String s2 = new StringBuilder().append ( s0 ).append ( "0\n" ).toString();
            int i2 = i + 1;
            s = s2;
            i = i2;
        }
        return s;
    }
}
