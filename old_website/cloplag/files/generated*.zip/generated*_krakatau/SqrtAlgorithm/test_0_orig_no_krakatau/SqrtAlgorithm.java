class SqrtAlgorithm {
    SqrtAlgorithm() {
        super();
    }
    public static double SqrtByAlogorithm ( double d ) {
        long j = ( long ) null;
        long j0 = ( long ) null;
        int i = 0;
        int i0 = 0;
        int i1 = 0;
        int i2 = 0;
        int i3 = 0;
        long j1 = ( long ) d;
        long j2 = ( long ) ( ( d - ( double ) j1 ) * 1000000.0 );
        long j3 = j1;
        int i4 = 0;
        while ( j3 >= 10L ) {
            long j4 = j3 / 10L;
            int i5 = i4 + 1;
            j3 = j4;
            i4 = i5;
        }
        int i6 = i4 + 1;
        long j5 = j2;
        int i7 = 0;
        while ( j5 >= 10L ) {
            long j6 = j5 / 10L;
            int i8 = i7 + 1;
            j5 = j6;
            i7 = i8;
        }
        int i9 = i7 + 1;
        if ( i6 % 2 == 1 ) {
            j = j1;
            j0 = j2;
            i = i6;
            i0 = i9;
            i1 = 0;
            i2 = 1;
            i3 = 0;
        } else {
            j = j1;
            j0 = j2;
            i = i6;
            i0 = i9;
            i1 = 0;
            i2 = 0;
            i3 = 0;
        }
        while ( true ) {
            int i10 = 0;
            int i11 = 0;
            if ( i2 == 1 ) {
                i10 = i - 1;
                i11 = 1;
            } else {
                i10 = i - 2;
                i11 = 0;
            }
            int i12 = 1;
            int i13 = 0;
            while ( i13 < i10 ) {
                int i14 = i12 * 10;
                int i15 = i13 + 1;
                i12 = i14;
                i13 = i15;
            }
            int i16 = ( int ) j / i12;
            int i17 = i1 * 2;
            int i18 = 1;
            int i19 = i17;
            while ( true ) {
                int i20 = 0;
                int i21 = 0;
                double d0 = 0.0;
                label10: {
                    label13: {
                        int i22 = 0;
                        label12: {
                            label14: {
                                if ( i19 != 0 ) {
                                    break label14;
                                }
                                if ( i16 - i18 * i18 < 0 ) {
                                    break label13;
                                }
                                i22 = 0;
                                break label12;
                            }
                            int i23 = i16 - i18 * ( i19 * 10 + i18 );
                            label11: {
                                if ( i23 >= 0 ) {
                                    break label11;
                                }
                                i20 = i19 / 2 * 10 + i18 - 1;
                                break label10;
                            }
                            i22 = i19;
                        }
                        i18 = i18 + 1;
                        i19 = i22;
                        continue;
                    }
                    i20 = i18 - 1;
                }
                int i24 = i20 / 10;
                int i25 = i20 % 10;
                long j7 = ( i24 == 0 ) ? j - ( long ) ( i20 * i20 * i12 ) : j - ( long ) ( ( i24 * 2 * 10 + i25 ) * i25 * i12 );
                int i26 = ( j7 >= 0L ) ? ( j7 != 0L ) ? 1 : 0 : -1;
                label0: {
                    label7: {
                        label9: {
                            if ( i26 == 0 ) {
                                break label9;
                            }
                            break label7;
                        }
                        int i27 = ( j0 < 0L ) ? -1 : ( j0 == 0L ) ? 0 : 1;
                        label8: {
                            if ( i27 == 0 ) {
                                break label8;
                            }
                            break label7;
                        }
                        if ( i10 > 0 ) {
                            int i28 = i10 / 2;
                            int i29 = 1;
                            int i30 = 0;
                            while ( i30 < i28 ) {
                                int i31 = i29 * 10;
                                int i32 = i30 + 1;
                                i29 = i31;
                                i30 = i32;
                            }
                            i21 = i20 * i29;
                            break label0;
                        } else {
                            i21 = i20;
                            break label0;
                        }
                    }
                    int i33 = ( i11 == 1 ) ? i + -1 : i + -2;
                    label2: {
                        long j8 = ( long ) null;
                        long j9 = ( long ) null;
                        int i34 = 0;
                        int i35 = 0;
                        int i36 = 0;
                        label5: {
                            long j10 = ( long ) null;
                            long j11 = ( long ) null;
                            int i37 = 0;
                            label6: {
                                if ( i33 <= 0 ) {
                                    break label6;
                                }
                                j8 = j7;
                                j9 = j0;
                                i34 = i33;
                                i35 = i0;
                                i36 = i3;
                                break label5;
                            }
                            int i38 = ( j7 >= 0L ) ? ( j7 != 0L ) ? 1 : 0 : -1;
                            label3: {
                                label4: {
                                    if ( i38 <= 0 ) {
                                        break label4;
                                    }
                                    break label3;
                                }
                                if ( j0 <= 0L ) {
                                    break label2;
                                }
                            }
                            label1: {
                                if ( i3 < 5 ) {
                                    break label1;
                                }
                                i21 = i20;
                                break label0;
                            }
                            int i39 = i3 + 1;
                            long j12 = j7 * 100L;
                            if ( j0 > 0L ) {
                                int i40 = i0 + -2;
                                int i41 = 1;
                                int i42 = 0;
                                while ( i42 < i40 ) {
                                    int i43 = i41 * 10;
                                    int i44 = i42 + 1;
                                    i41 = i43;
                                    i42 = i44;
                                }
                                long j13 = j12 + j0 / ( long ) i41;
                                long j14 = j0 % ( long ) i41;
                                j10 = j13;
                                j11 = j14;
                                i37 = i40;
                            } else {
                                j10 = j12;
                                j11 = j0;
                                i37 = i0;
                            }
                            int i45 = i33 + 2;
                            j8 = j10;
                            j9 = j11;
                            i34 = i45;
                            i35 = i37;
                            i36 = i39;
                        }
                        j = j8;
                        j0 = j9;
                        i = i34;
                        i0 = i35;
                        i1 = i20;
                        i2 = 0;
                        i3 = i36;
                        break;
                    }
                    i21 = i20;
                }
                if ( i3 == 0 ) {
                    d0 = ( double ) i21;
                } else {
                    int i46 = 1;
                    int i47 = 0;
                    while ( i47 < i3 ) {
                        int i48 = i46 * 10;
                        int i49 = i47 + 1;
                        i46 = i48;
                        i47 = i49;
                    }
                    d0 = ( double ) i21 / ( double ) i46;
                }
                return d0;
            }
        }
    }
    public static void main ( String[] a ) {
        double d = 0.0;
        while ( d <= 10000.0 ) {
            System.out.print ( "sqrt(" );
            System.out.print ( d );
            System.out.print ( ") = " );
            System.out.print ( SqrtAlgorithm.SqrtByAlogorithm ( d ) );
            System.out.print ( ", " );
            System.out.println ( Math.sqrt ( d ) );
            d = d + 50.0;
        }
    }
}
