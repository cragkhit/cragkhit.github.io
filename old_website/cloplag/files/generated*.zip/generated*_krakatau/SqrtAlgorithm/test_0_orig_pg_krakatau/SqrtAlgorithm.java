class SqrtAlgorithm {
    SqrtAlgorithm() {
        super();
    }
    public static void main ( String[] a ) {
        double d = 0.0;
        label0: while ( d <= 10000.0 ) {
            int i = 0;
            int i0 = 0;
            long j = ( long ) null;
            long j0 = ( long ) null;
            int i1 = 0;
            int i2 = 0;
            int i3 = 0;
            System.out.print ( "sqrt(" );
            System.out.print ( d );
            System.out.print ( ") = " );
            java.io.PrintStream a0 = System.out;
            long j1 = ( long ) d;
            long j2 = ( long ) ( ( d - ( double ) j1 ) * 1000000.0 );
            int i4 = 0;
            long j3 = j1;
            while ( j3 >= 10L ) {
                long j4 = j3 / 10L;
                i4 = i4 + 1;
                j3 = j4;
            }
            int i5 = i4 + 1;
            int i6 = 0;
            long j5 = j2;
            while ( j5 >= 10L ) {
                long j6 = j5 / 10L;
                i6 = i6 + 1;
                j5 = j6;
            }
            int i7 = i6 + 1;
            if ( i5 % 2 == 1 ) {
                i = i5;
                i0 = i7;
                j = j1;
                j0 = j2;
                i1 = 0;
                i2 = 1;
                i3 = 0;
            } else {
                i = i5;
                i0 = i7;
                j = j1;
                j0 = j2;
                i1 = 0;
                i2 = 0;
                i3 = 0;
            }
            while ( true ) {
                int i8 = 0;
                int i9 = 0;
                if ( i2 == 1 ) {
                    i8 = i - 1;
                    i9 = 1;
                } else {
                    i8 = i - 2;
                    i9 = 0;
                }
                int i10 = 0;
                int i11 = 1;
                while ( i10 < i8 ) {
                    int i12 = i11 * 10;
                    i10 = i10 + 1;
                    i11 = i12;
                }
                int i13 = ( int ) j / i11;
                int i14 = i1 << 1;
                int i15 = 1;
                int i16 = i14;
                while ( true ) {
                    int i17 = 0;
                    int i18 = 0;
                    double d0 = 0.0;
                    label11: {
                        label14: {
                            int i19 = 0;
                            label13: {
                                label15: {
                                    if ( i16 != 0 ) {
                                        break label15;
                                    }
                                    if ( i13 - i15 * i15 < 0 ) {
                                        break label14;
                                    }
                                    i19 = 0;
                                    break label13;
                                }
                                int i20 = i13 - i15 * ( i16 * 10 + i15 );
                                label12: {
                                    if ( i20 >= 0 ) {
                                        break label12;
                                    }
                                    i17 = i16 / 2 * 10 + i15 - 1;
                                    break label11;
                                }
                                i19 = i16;
                            }
                            i15 = i15 + 1;
                            i16 = i19;
                            continue;
                        }
                        i17 = i15 - 1;
                    }
                    int i21 = i17 / 10;
                    int i22 = i17 % 10;
                    long j7 = ( i21 == 0 ) ? j - ( long ) ( i17 * i17 * i11 ) : j - ( long ) ( ( ( i21 << 1 ) * 10 + i22 ) * i22 * i11 );
                    int i23 = ( j7 >= 0L ) ? ( j7 != 0L ) ? 1 : 0 : -1;
                    label1: {
                        label8: {
                            label10: {
                                if ( i23 == 0 ) {
                                    break label10;
                                }
                                break label8;
                            }
                            int i24 = ( j0 < 0L ) ? -1 : ( j0 == 0L ) ? 0 : 1;
                            label9: {
                                if ( i24 == 0 ) {
                                    break label9;
                                }
                                break label8;
                            }
                            if ( i8 > 0 ) {
                                int i25 = i8 / 2;
                                int i26 = 0;
                                int i27 = 1;
                                while ( i26 < i25 ) {
                                    int i28 = i27 * 10;
                                    i26 = i26 + 1;
                                    i27 = i28;
                                }
                                i18 = i17 * i27;
                                break label1;
                            } else {
                                i18 = i17;
                                break label1;
                            }
                        }
                        int i29 = ( i9 == 1 ) ? i + -1 : i + -2;
                        label3: {
                            label2: {
                                int i30 = 0;
                                int i31 = 0;
                                long j8 = ( long ) null;
                                long j9 = ( long ) null;
                                int i32 = 0;
                                label6: {
                                    int i33 = 0;
                                    long j10 = ( long ) null;
                                    long j11 = ( long ) null;
                                    label7: {
                                        if ( i29 <= 0 ) {
                                            break label7;
                                        }
                                        i30 = i29;
                                        i31 = i0;
                                        j8 = j7;
                                        j9 = j0;
                                        i32 = i3;
                                        break label6;
                                    }
                                    int i34 = ( j7 >= 0L ) ? ( j7 != 0L ) ? 1 : 0 : -1;
                                    label4: {
                                        label5: {
                                            if ( i34 <= 0 ) {
                                                break label5;
                                            }
                                            break label4;
                                        }
                                        if ( j0 <= 0L ) {
                                            break label3;
                                        }
                                    }
                                    if ( i3 >= 5 ) {
                                        break label2;
                                    }
                                    int i35 = i3 + 1;
                                    long j12 = j7 * 100L;
                                    if ( j0 > 0L ) {
                                        int i36 = i0 + -2;
                                        int i37 = 0;
                                        int i38 = 1;
                                        while ( i37 < i36 ) {
                                            int i39 = i38 * 10;
                                            i37 = i37 + 1;
                                            i38 = i39;
                                        }
                                        long j13 = j12 + j0 / ( long ) i38;
                                        long j14 = j0 % ( long ) i38;
                                        i33 = i36;
                                        j10 = j13;
                                        j11 = j14;
                                    } else {
                                        i33 = i0;
                                        j10 = j12;
                                        j11 = j0;
                                    }
                                    i30 = i29 + 2;
                                    i31 = i33;
                                    j8 = j10;
                                    j9 = j11;
                                    i32 = i35;
                                }
                                i = i30;
                                i0 = i31;
                                j = j8;
                                j0 = j9;
                                i1 = i17;
                                i2 = 0;
                                i3 = i32;
                                break;
                            }
                            i18 = i17;
                            break label1;
                        }
                        i18 = i17;
                    }
                    if ( i3 == 0 ) {
                        d0 = ( double ) i18;
                    } else {
                        int i40 = 0;
                        int i41 = 1;
                        while ( i40 < i3 ) {
                            int i42 = i41 * 10;
                            i40 = i40 + 1;
                            i41 = i42;
                        }
                        d0 = ( double ) i18 / ( double ) i41;
                    }
                    a0.print ( d0 );
                    System.out.print ( ", " );
                    System.out.println ( Math.sqrt ( d ) );
                    d = d + 50.0;
                    continue label0;
                }
            }
        }
    }
}
