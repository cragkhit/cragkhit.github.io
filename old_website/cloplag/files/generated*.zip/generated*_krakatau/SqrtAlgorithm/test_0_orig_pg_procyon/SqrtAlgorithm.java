class SqrtAlgorithm {
    SqrtAlgorithm() {
        super();
    }
    public static void main ( String[] a ) {
        double d = 0.0;
        label0: while ( d <= 10000.0 ) {
            long j = ( long ) null;
            long j0 = ( long ) null;
            int i = 0;
            int i0 = 0;
            int i1 = 0;
            int i2 = 0;
            int i3 = 0;
            System.out.print ( "sqrt(" );
            System.out.print ( d );
            System.out.print ( ") = " );
            java.io.PrintStream a0 = System.out;
            long j1 = ( long ) d;
            long j2 = ( long ) ( ( d - ( double ) j1 ) * 1000000.0 );
            long j3 = j1;
            int i4 = 0;
            while ( j3 >= 10L ) {
                long j4 = j3 / 10L;
                int i5 = i4 + 1;
                j3 = j4;
                i4 = i5;
            }
            int i6 = i4 + 1;
            long j5 = j2;
            int i7 = 0;
            while ( j5 >= 10L ) {
                long j6 = j5 / 10L;
                int i8 = i7 + 1;
                j5 = j6;
                i7 = i8;
            }
            int i9 = i7 + 1;
            if ( i6 % 2 != 1 ) {
                j = j1;
                j0 = j2;
                i = 0;
                i0 = 0;
                i1 = 0;
                i2 = i6;
                i3 = i9;
            } else {
                j = j1;
                j0 = j2;
                i = 0;
                i0 = 1;
                i1 = 0;
                i2 = i6;
                i3 = i9;
            }
            while ( true ) {
                int i10 = 0;
                int i11 = 0;
                if ( i0 != 1 ) {
                    i10 = i2 - 2;
                    i11 = 0;
                } else {
                    i10 = i2 - 1;
                    i11 = 1;
                }
                int i12 = 1;
                int i13 = 0;
                while ( i13 < i10 ) {
                    int i14 = i12 * 10;
                    int i15 = i13 + 1;
                    i12 = i14;
                    i13 = i15;
                }
                int i16 = ( int ) j / i12;
                int i17 = i << 1;
                int i18 = 1;
                while ( true ) {
                    int i19 = 0;
                    int i20 = 0;
                    double d0 = 0.0;
                    label4: {
                        label5: {
                            label6: {
                                int i21 = 0;
                                label7: {
                                    label8: {
                                        if ( i17 == 0 ) {
                                            break label8;
                                        }
                                        if ( i16 - i18 * ( i17 * 10 + i18 ) >= 0 ) {
                                            i21 = i17;
                                            break label7;
                                        } else {
                                            break label6;
                                        }
                                    }
                                    if ( i16 - i18 * i18 >= 0 ) {
                                        i21 = 0;
                                    } else {
                                        break label5;
                                    }
                                }
                                int i22 = i18 + 1;
                                i17 = i21;
                                i18 = i22;
                                continue;
                            }
                            i19 = i17 / 2 * 10 + i18 - 1;
                            break label4;
                        }
                        i19 = i18 - 1;
                    }
                    int i23 = i19 / 10;
                    int i24 = i19 % 10;
                    long j7 = ( i23 != 0 ) ? j - ( long ) ( ( ( i23 << 1 ) * 10 + i24 ) * i24 * i12 ) : j - ( long ) ( i19 * i19 * i12 );
                    int i25 = ( j7 < 0L ) ? -1 : ( j7 == 0L ) ? 0 : 1;
                    label1: {
                        label3: {
                            if ( i25 != 0 ) {
                                break label3;
                            }
                            if ( j0 != 0L ) {
                                break label3;
                            }
                            if ( i10 <= 0 ) {
                                i20 = i19;
                                break label1;
                            } else {
                                int i26 = i10 / 2;
                                int i27 = 1;
                                int i28 = 0;
                                while ( i28 < i26 ) {
                                    int i29 = i27 * 10;
                                    int i30 = i28 + 1;
                                    i27 = i29;
                                    i28 = i30;
                                }
                                i20 = i19 * i27;
                                break label1;
                            }
                        }
                        int i31 = ( i11 != 1 ) ? i2 + -2 : i2 + -1;
                        if ( i31 > 0 ) {
                            j = j7;
                            i = i19;
                            i0 = 0;
                            i2 = i31;
                            break;
                        }
                        int i32 = ( j7 < 0L ) ? -1 : ( j7 == 0L ) ? 0 : 1;
                        label2: {
                            if ( i32 > 0 ) {
                                break label2;
                            }
                            if ( j0 <= 0L ) {
                                i20 = i19;
                                break label1;
                            }
                        }
                        if ( i1 < 5 ) {
                            long j8 = ( long ) null;
                            long j9 = ( long ) null;
                            int i33 = 0;
                            int i34 = i1 + 1;
                            long j10 = j7 * 100L;
                            if ( j0 <= 0L ) {
                                j8 = j10;
                                j9 = j0;
                                i33 = i3;
                            } else {
                                int i35 = i3 + -2;
                                int i36 = 1;
                                int i37 = 0;
                                while ( i37 < i35 ) {
                                    int i38 = i36 * 10;
                                    int i39 = i37 + 1;
                                    i36 = i38;
                                    i37 = i39;
                                }
                                long j11 = j10 + j0 / ( long ) i36;
                                long j12 = j0 % ( long ) i36;
                                j8 = j11;
                                j9 = j12;
                                i33 = i35;
                            }
                            int i40 = i31 + 2;
                            j = j8;
                            j0 = j9;
                            i = i19;
                            i0 = 0;
                            i1 = i34;
                            i2 = i40;
                            i3 = i33;
                            break;
                        }
                        i20 = i19;
                    }
                    if ( i1 != 0 ) {
                        int i41 = 1;
                        int i42 = 0;
                        while ( i42 < i1 ) {
                            int i43 = i41 * 10;
                            int i44 = i42 + 1;
                            i41 = i43;
                            i42 = i44;
                        }
                        d0 = ( double ) ( i20 / i41 );
                    } else {
                        d0 = ( double ) i20;
                    }
                    a0.print ( d0 );
                    System.out.print ( ", " );
                    System.out.println ( Math.sqrt ( d ) );
                    d = d + 50.0;
                    continue label0;
                }
            }
        }
    }
}
