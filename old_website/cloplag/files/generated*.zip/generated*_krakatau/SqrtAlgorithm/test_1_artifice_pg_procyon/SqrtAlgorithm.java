class SqrtAlgorithm {
    SqrtAlgorithm() {
        super();
    }
    public static void main ( String[] a ) {
        double d = 0.0;
        label0: while ( d <= 10000.0 ) {
            long j = ( long ) null;
            long j0 = ( long ) null;
            int i = 0;
            int i0 = 0;
            int i1 = 0;
            int i2 = 0;
            int i3 = 0;
            System.out.print ( "sqrt(" );
            System.out.print ( d );
            System.out.print ( ") = " );
            java.io.PrintStream a0 = System.out;
            long j1 = ( long ) d;
            long j2 = ( long ) ( ( d - ( double ) j1 ) * 1000000.0 );
            long j3 = j1;
            int i4 = 0;
            while ( j3 >= 10L ) {
                long j4 = j3 / 10L;
                int i5 = i4 + 1;
                j3 = j4;
                i4 = i5;
            }
            int i6 = i4 + 1;
            long j5 = j2;
            int i7 = 0;
            while ( j5 >= 10L ) {
                long j6 = j5 / 10L;
                int i8 = i7 + 1;
                j5 = j6;
                i7 = i8;
            }
            int i9 = i7 + 1;
            if ( i6 % 2 != 1 ) {
                j = j1;
                j0 = j2;
                i = 0;
                i0 = 0;
                i1 = 0;
                i2 = i6;
                i3 = i9;
            } else {
                j = j1;
                j0 = j2;
                i = 0;
                i0 = 1;
                i1 = 0;
                i2 = i6;
                i3 = i9;
            }
            while ( true ) {
                int i10 = 0;
                int i11 = 0;
                if ( i0 != 1 ) {
                    int i12 = i2 - 2;
                    i10 = 0;
                    i11 = i12;
                } else {
                    int i13 = i2 - 1;
                    i10 = 1;
                    i11 = i13;
                }
                int i14 = 1;
                int i15 = 0;
                while ( i15 < i11 ) {
                    int i16 = i14 * 10;
                    int i17 = i15 + 1;
                    i14 = i16;
                    i15 = i17;
                }
                int i18 = ( int ) j / i14;
                int i19 = i << 1;
                int i20 = 1;
                while ( true ) {
                    int i21 = 0;
                    int i22 = 0;
                    double d0 = 0.0;
                    label4: {
                        label5: {
                            label6: {
                                int i23 = 0;
                                label7: {
                                    label8: {
                                        if ( i19 == 0 ) {
                                            break label8;
                                        }
                                        if ( i18 - i20 * ( i19 * 10 + i20 ) >= 0 ) {
                                            i23 = i19;
                                            break label7;
                                        } else {
                                            break label6;
                                        }
                                    }
                                    if ( i18 - i20 * i20 >= 0 ) {
                                        i23 = 0;
                                    } else {
                                        break label5;
                                    }
                                }
                                int i24 = i20 + 1;
                                i19 = i23;
                                i20 = i24;
                                continue;
                            }
                            i21 = i19 / 2 * 10 + i20 - 1;
                            break label4;
                        }
                        i21 = i20 - 1;
                    }
                    int i25 = i21 / 10;
                    int i26 = i21 % 10;
                    long j7 = ( i25 != 0 ) ? j - ( long ) ( 0 - ( ( i25 << 1 ) * 10 + i26 ) * i26 * i14 ) : j - ( long ) ( 0 - i21 * i21 * i14 );
                    int i27 = ( j7 < 0L ) ? -1 : ( j7 == 0L ) ? 0 : 1;
                    label1: {
                        label3: {
                            if ( i27 != 0 ) {
                                break label3;
                            }
                            if ( j0 != 0L ) {
                                break label3;
                            }
                            if ( i11 <= 0 ) {
                                i22 = i21;
                                break label1;
                            } else {
                                int i28 = i11 / 2;
                                int i29 = 1;
                                int i30 = 0;
                                while ( i30 < i28 ) {
                                    int i31 = i29 * 10;
                                    int i32 = i30 + 1;
                                    i29 = i31;
                                    i30 = i32;
                                }
                                i22 = i21 * i29;
                                break label1;
                            }
                        }
                        int i33 = ( i10 != 1 ) ? i2 + -2 : i2 + -1;
                        if ( i33 > 0 ) {
                            j = j7;
                            i = i21;
                            i0 = 0;
                            i2 = i33;
                            break;
                        }
                        int i34 = ( j7 < 0L ) ? -1 : ( j7 == 0L ) ? 0 : 1;
                        label2: {
                            if ( i34 > 0 ) {
                                break label2;
                            }
                            if ( j0 <= 0L ) {
                                i22 = i21;
                                break label1;
                            }
                        }
                        if ( i1 < 5 ) {
                            long j8 = ( long ) null;
                            long j9 = ( long ) null;
                            int i35 = 0;
                            int i36 = i1 + 1;
                            long j10 = j7 * 100L;
                            if ( j0 <= 0L ) {
                                j8 = j10;
                                j9 = j0;
                                i35 = i3;
                            } else {
                                int i37 = i3 + -2;
                                int i38 = 1;
                                int i39 = 0;
                                while ( i39 < i37 ) {
                                    int i40 = i38 * 10;
                                    int i41 = i39 + 1;
                                    i38 = i40;
                                    i39 = i41;
                                }
                                long j11 = j10 + j0 / ( long ) i38;
                                long j12 = j0 % ( long ) i38;
                                j8 = j11;
                                j9 = j12;
                                i35 = i37;
                            }
                            int i42 = i33 + 2;
                            j = j8;
                            j0 = j9;
                            i = i21;
                            i0 = 0;
                            i1 = i36;
                            i2 = i42;
                            i3 = i35;
                            break;
                        }
                        i22 = i21;
                    }
                    if ( i1 != 0 ) {
                        int i43 = 1;
                        int i44 = 0;
                        while ( i44 < i1 ) {
                            int i45 = i43 * 10;
                            int i46 = i44 + 1;
                            i43 = i45;
                            i44 = i46;
                        }
                        d0 = ( double ) ( i22 / i43 );
                    } else {
                        d0 = ( double ) i22;
                    }
                    a0.print ( d0 );
                    System.out.print ( ", " );
                    System.out.println ( Math.sqrt ( d ) );
                    d = d + 50.0;
                    continue label0;
                }
            }
        }
    }
}
