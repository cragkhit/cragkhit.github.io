import java.util.ArrayList;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class ON2_00_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null ) {
            return new String[0];
        }
        String[] addyArray = addresses.split ( Pattern.quote ( Character.toString ( separator ) ) );
        String[] valids;
        ArrayList<String> validAddys = new ArrayList<String>();
        Matcher m;
        for ( String addy : addyArray ) {
            addy = addy.trim();
            if ( addy != "" ) {
                m = emailPattern.matcher ( addy );
                if ( m.matches() ) {
                    validAddys.add ( addy );
                } else {
                    invalidAddresses.add ( addy );
                }
            }
        }
        valids = new String[validAddys.size()];
        validAddys.toArray ( valids );
        return valids;
    }
}
