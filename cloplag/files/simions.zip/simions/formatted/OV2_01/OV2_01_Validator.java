import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Pattern;
public class OV2_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    private char separator = 0;
    private ArrayList<String> AddressList;
    private ArrayList<String> CopyToList ( String addresses ) {
        ArrayList<String> myList = new ArrayList<String>();
        String currentAddr = "";
        int endIndex = 0;
        while ( ( addresses.length() > 1 ) && ! ( addresses.isEmpty() ) ) {
            if ( addresses.indexOf ( this.separator ) > -1 ) {
                endIndex = addresses.indexOf ( this.separator );
                currentAddr = addresses.substring ( 0, endIndex );
                myList.add ( currentAddr );
                addresses = addresses.substring ( endIndex + 1 );
            } else {
                myList.add ( addresses );
                break;
            }
        }
        if ( addresses.length() == 1 ) {
            myList.add ( addresses );
        }
        return myList;
    }
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        ArrayList<String> validAddresses = new ArrayList<String>();
        String currentAdd = "";
        this.separator = separator;
        String[] emptyString = new String[0];
        if ( addresses == null ) {
            return emptyString;
        }
        if ( addresses.isEmpty() ) {
            return emptyString;
        }
        this.AddressList = CopyToList ( addresses );
        Iterator<String> Iter = this.AddressList.iterator();
        if ( Iter.hasNext() ) {
            currentAdd = Iter.next();
        } else {
            currentAdd = "";
        }
        while ( !currentAdd.equals ( "" ) ) {
            if ( ( emailPattern.matcher ( currentAdd ).matches() ) && ! ( invalidAddresses.contains ( currentAdd ) ) ) {
                validAddresses.add ( currentAdd );
            } else {
                invalidAddresses.add ( currentAdd );
            }
            if ( Iter.hasNext() ) {
                currentAdd = Iter.next();
            } else {
                currentAdd = "";
            }
        }
        Iterator<String> vIter = validAddresses.iterator();
        String[] myValid = new String[validAddresses.size()];
        int count = 0;
        while ( vIter.hasNext() ) {
            myValid[count] = vIter.next();
        }
        return myValid;
    }
}
