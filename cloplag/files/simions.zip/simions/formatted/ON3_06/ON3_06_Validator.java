import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class ON3_06_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        String[] empty = new String[0];
        char a = ';';
        if ( addresses == null || addresses.length() == 0 ) {
            return empty;
        }
        String newaddresses = addresses.replace ( separator, a );
        String[] testAddresses = newaddresses.split ( String.valueOf ( a ) );
        String validAddresses = "";
        for ( int i = 0; i < testAddresses.length ; i++ ) {
            if ( emailPattern.matcher ( testAddresses[i] ).matches() ) {
                validAddresses += ( testAddresses[i] + ";" );
            } else {
                invalidAddresses.add ( testAddresses[i] );
            }
        }
        String[] validAddressesArray = validAddresses.split ( ";" );
        if ( validAddressesArray[0].equals ( "" ) ) {
            return new String[0];
        }
        return validAddressesArray;
    }
}
