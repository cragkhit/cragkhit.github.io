import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Pattern;
public class D7_02_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null ) {
            return new String[0];
        }
        StringTokenizer tokens = new StringTokenizer ( addresses, "" + separator );
        Vector<String> valids = new Vector<String>();
        while ( tokens.hasMoreTokens() ) {
            String address = tokens.nextToken();
            if ( emailPattern.matcher ( address ).matches() ) {
                valids.add ( address );
            } else {
                invalidAddresses.add ( address );
            }
        }
        return valids.toArray ( new String[valids.size()] );
    }
}
