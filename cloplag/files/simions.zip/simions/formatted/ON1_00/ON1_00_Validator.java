import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.regex.*;
public class ON1_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        List<String> valids = new ArrayList<String>();
        if ( addresses == null ) return new String[] {};
        String sep = Character.toString ( separator );
        if ( separator == '\\' ) {
            sep = "\\\\";
        }
        String[] add_list = addresses.split ( sep );
        for ( int i = 0; i < add_list.length; i++ ) {
            add_list[i] = add_list[i].trim();
            Matcher m = emailPattern.matcher ( add_list[i] );
            if ( m.matches() ) {
                valids.add ( add_list[i] );
            } else if ( add_list[i] != "" ) {
                invalidAddresses.add ( add_list[i] );
            }
        }
        return valids.toArray ( new String[] {} );
    }
}
