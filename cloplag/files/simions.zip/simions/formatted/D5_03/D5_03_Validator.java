import java.util.*;
import java.util.regex.*;
public class D5_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "^[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+$" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.equals ( "" ) ) {
            return new String[0];
        }
        String sep =  String.valueOf ( separator );
        sep = Pattern.quote ( sep );
        String[] allAddresses = addresses.split ( "[\\s]*[" + sep + "][\\s]*" );
        List<String> validAddresses = new ArrayList<String>();
        for ( int i = 0; i < allAddresses.length; i++ ) {
            String address = allAddresses[i];
            if ( emailPattern.matcher ( address ).find() ) {
                validAddresses.add ( address );
            } else {
                invalidAddresses.add ( address );
            }
        }
        return validAddresses.toArray ( new String[0] );
    }
}
