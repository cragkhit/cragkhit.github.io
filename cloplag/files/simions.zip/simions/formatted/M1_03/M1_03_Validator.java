import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.lang.StringBuilder;
import java.util.regex.Matcher;
public class M1_03_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    private Matcher proof;
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        String[] leer = new String[0];
        if ( addresses == null || addresses.length() == 0 ) {
            return leer;
        }
        addresses = addresses + separator;
        int count = 0;
        StringBuilder s = new StringBuilder ( addresses );
        int index = 0;
        int anfang = 0;
        int validCounts = 0;
        for ( int i = 0; i < addresses.length(); i++ ) {
            if ( addresses.charAt ( i ) == separator ) {
                count += 1;
            }
        }
        String[] ea = new String[count];
        for ( int i = s.length() - 1; i >= 0; i-- ) {
            if ( s.charAt ( i ) == ' ' ) {
                s.deleteCharAt ( i );
            }
        }
        addresses = s.toString();
        for ( int i = 0; i < addresses.length(); i++ ) {
            if ( addresses.charAt ( i ) == separator ) {
                ea[index] = addresses.substring ( anfang, i );
                anfang = i + 1;
                index += 1;
            }
        }
        for ( int i = 0; i < count; i++ ) {
            proof = emailPattern.matcher ( ea[i] );
            if ( proof.matches() ) {
                validCounts += 1;
            }
        }
        String[] validAddresses = new String[validCounts];
        index = 0;
        for ( int i = 0; i < count; i++ ) {
            proof = emailPattern.matcher ( ea[i] );
            if ( proof.matches() ) {
                validAddresses[index] = ea[i];
                index++;
            } else {
                invalidAddresses.add ( ea[i] );
            }
        }
        if ( validAddresses == null ) {
            return leer;
        } else {
            return validAddresses;
        }
    }
}
