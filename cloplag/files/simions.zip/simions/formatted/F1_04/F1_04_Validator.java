import java.util.ArrayList;
import java.util.Set;
import java.util.regex.*;
public class F1_04_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null ) {
            return new String[0];
        } else if ( addresses.equals ( "" ) ) {
            return new String[0];
        }
        ArrayList<String> saneAddresses = new ArrayList<String>();
        String sep = Pattern.quote ( Character.toString ( separator ) );
        String[] tmp = addresses.split ( sep );
        for ( String currentAddress : tmp ) {
            Matcher m = emailPattern.matcher ( currentAddress );
            if ( m.matches() ) {
                saneAddresses.add ( currentAddress );
            } else {
                invalidAddresses.add ( currentAddress );
            }
        }
        return saneAddresses.toArray ( new String[0] );
    }
}
