import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
public class I1_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        List<String> validAddresses = new ArrayList<String>();
        System.out.println ( "adresses: " + addresses );
        if ( addresses == null ) {
            System.out.println ( "null string" );
            return new String[0];
        } else if ( addresses.isEmpty() ) {
            System.out.println ( "leerer string" );
            return new String[0];
        }
        StringTokenizer st = new StringTokenizer ( addresses, "" + separator );
        while ( st.hasMoreTokens() ) {
            String s = st.nextToken();
            System.out.print ( "check -> " + s );
            if ( validateSingleAdress ( s ) ) {
                System.out.println ( " --> valid" );
                validAddresses.add ( s );
            } else {
                System.out.println ( " --> invalid" );
                invalidAddresses.add ( s );
            }
        }
        String[] a = new String[validAddresses.size()];
        validAddresses.toArray ( a );
        return a;
    }
    private boolean validateSingleAdress ( String address ) {
        StringTokenizer st = new StringTokenizer ( address, "@" );
        if ( st.countTokens() != 2 ) {
            return false;
        } else {
            String left = st.nextToken();
            String right = st.nextToken();
            if ( left.isEmpty() ) {
                return false;
            }
            if ( right.isEmpty() ) {
                return false;
            }
            if ( !checkCharacters ( left ) || !checkCharacters ( right ) ) {
                return false;
            }
            if ( !hasDomain ( right ) ) {
                return false;
            }
        }
        return true;
    }
    private boolean checkCharacters ( String right ) {
        for ( int i = 0; i < right.length(); i++ ) {
            char c = right.charAt ( i );
            if ( ( c < 'A' || c > 'Z' ) && ( c < 'a' || c > 'z' ) && ( c < '0' || c > '9' ) && c != '.' ) {
                return false;
            }
        }
        return true;
    }
    private boolean hasDomain ( String right ) {
        StringTokenizer st = new StringTokenizer ( right, "." );
        if ( st.countTokens() < 2 ) {
            return false;
        }
        if ( right.endsWith ( "." ) ) {
            return false;
        }
        return true;
    }
}
