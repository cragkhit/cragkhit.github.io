import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class ON3_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        ArrayList<String> validadr = new ArrayList<String>();
        if ( addresses == null ) {
            return new String[0];
        }
        String sepstring = Character.toString ( separator );
        if ( sepstring.equals ( "\\" ) ) {
            sepstring = "\\\\";
        }
        String[] singleadr = addresses.split ( sepstring );
        for ( int a = 0; a < singleadr.length; a++ ) {
            String t = singleadr[a].trim();
            if ( emailPattern.matcher ( t ).matches() ) {
                validadr.add ( t );
            } else if ( !t.isEmpty() ) {
                invalidAddresses.add ( t );
            }
        }
        return ( String[] ) validadr.toArray ( new String[0] );
    }
}
