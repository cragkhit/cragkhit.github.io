import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class OV5_00_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.equals ( "" ) ) {
            return new String[0];
        }
        List<String> validAddresses = new ArrayList<String> ();
        StringTokenizer tokenizer = new StringTokenizer ( addresses, String.valueOf ( separator ) );
        String currentAddress;
        Matcher matcher;
        while ( tokenizer.hasMoreTokens() ) {
            currentAddress = tokenizer.nextToken();
            matcher = emailPattern.matcher ( currentAddress );
            if ( matcher.matches() ) {
                validAddresses.add ( currentAddress );
            } else {
                invalidAddresses.add ( currentAddress );
            }
        }
        return validAddresses.toArray ( new String[validAddresses.size()] );
    }
}
