import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
public class ON2_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.length() == 0 ) {
            return new String[0];
        }
        StringTokenizer addressTokenizer = new StringTokenizer ( addresses, Character.toString ( separator ) );
        String toValidate;
        ArrayList<String> returnList = new ArrayList<String>();
        while ( addressTokenizer.hasMoreTokens() ) {
            toValidate = addressTokenizer.nextToken().trim();
            if ( emailPattern.matcher ( toValidate ).matches() ) {
                returnList.add ( toValidate );
            } else {
                invalidAddresses.add ( toValidate );
            }
        }
        String[] arr = new String[returnList.size()];
        for ( int i = 0; i < arr.length; i++ ) {
            arr[i] = ( String ) returnList.get ( i );
        }
        return arr;
    }
}
