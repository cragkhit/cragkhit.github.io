import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class D5_00_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        char c;
        String s = "";
        int i = 0;
        Matcher m;
        List<String> valid = new ArrayList<String>();
        if ( addresses != null ) {
            while ( addresses.length() > i ) {
                c = addresses.charAt ( i );
                i++;
                if ( c == separator ) {
                    m = emailPattern.matcher ( s );
                    if ( m.matches() ) {
                        valid.add ( s );
                    } else {
                        invalidAddresses.add ( s );
                    }
                    s = "";
                } else {
                    if ( c != ' ' ) {
                        s = s + c;
                    }
                }
            }
            if ( s.length() > 0 ) {
                m = emailPattern.matcher ( s );
                if ( m.matches() ) {
                    valid.add ( s );
                } else {
                    invalidAddresses.add ( s );
                }
            }
            String[] validr = new String[valid.size()];
            i = 0;
            while ( i < valid.size() ) {
                validr[i] = valid.get ( i );
                i++;
            }
            return validr;
        } else {
            String[] b = new String[0];
            return b;
        }
    }
}
