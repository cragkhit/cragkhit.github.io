import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.omg.CosNaming.NamingContextExtPackage.InvalidAddress;
public class M3_09_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.isEmpty() ) {
            return new String[0];
        }
        List<String> validaddresses =  new ArrayList<String>();
        String[] splitted = addresses.split ( Pattern.quote ( String.valueOf ( separator ) ) );
        for ( String str : splitted ) {
            Matcher m = emailPattern.matcher ( str );
            if ( m.matches() ) {
                validaddresses.add ( str );
            } else {
                invalidAddresses.add ( str );
            }
        }
        return validaddresses.toArray ( new String[0] );
    }
}
