import java.util.ArrayList;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class F3_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        ArrayList<String> ValidAddresses = new ArrayList<String>();
        if ( addresses == null || addresses.length() == 0 ) {
            return new String[] {};
        } else {
            String[] List = addresses.split ( "\\" + separator );
            for ( int i = 0; i < List.length; i++ ) {
                Matcher m = emailPattern.matcher ( List[i] );
                boolean b = m.matches();
                if ( b ) {
                    ValidAddresses.add ( List[i] );
                } else {
                    invalidAddresses.add ( List[i] );
                }
            }
            return ValidAddresses.toArray ( new String[] {} );
        }
    }
}
