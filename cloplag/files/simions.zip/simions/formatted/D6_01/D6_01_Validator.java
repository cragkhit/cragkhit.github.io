import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class D6_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null ) {
            return new String[0];
        }
        if ( addresses.isEmpty() ) {
            return new String[0];
        }
        String seq = this.emailPattern.quote ( "" + separator );
        String[] emails = addresses.split ( seq );
        int i = 0;
        int validCount = 0;
        for ( i = 0; i < emails.length ; i++ ) {
            Matcher m = this.emailPattern.matcher ( emails[i] );
            boolean b = m.matches();
            if ( b ) {
                validCount++;
            } else {
                invalidAddresses.add ( emails[i] );
            }
        }
        String[] validAddresses = new String[validCount];
        int j = 0;
        for ( i = 0; i < emails.length ; i++ ) {
            Matcher m = this.emailPattern.matcher ( emails[i] );
            boolean b = m.matches();
            if ( b ) {
                validAddresses[j++] = emails[i];
            }
        }
        return validAddresses;
    }
}
