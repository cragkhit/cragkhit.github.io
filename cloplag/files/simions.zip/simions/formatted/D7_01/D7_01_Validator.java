import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class D7_01_Validator {
    private final Pattern	emailPattern	= Pattern
            .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( final String addresses,
            final char separator, final Set<String> invalidAddresses ) {
        if ( addresses != null && !addresses.isEmpty() ) {
            final String[] addressArray = addresses.split ( "\\s*" + separator
                                          + "\\s*" );
            final List<String> validAddresses = new ArrayList<String>();
            for ( final String email : addressArray ) {
                if ( emailPattern.matcher ( email ).matches() ) {
                    validAddresses.add ( email );
                } else {
                    invalidAddresses.add ( email );
                }
            }
            return validAddresses.toArray ( new String[] {} );
        }
        return new String[] {};
    }
}
