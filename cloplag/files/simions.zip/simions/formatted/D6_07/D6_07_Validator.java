import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.*;
public class D6_07_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        try {
            if ( addresses.equals ( "" ) )
                return new String[] {};
        } catch ( Exception e ) {
            return new String[] {};
        }
        String sep0 = "" + separator;
        String sep = Pattern.quote ( sep0 );
        String[] mailAdresses = addresses.split ( sep );
        Matcher m;
        List<String> ads = new ArrayList<String>();
        for ( int x = 0; x < mailAdresses.length; x++ ) {
            mailAdresses[x] = mailAdresses[x].trim();
            m = emailPattern.matcher ( mailAdresses[x] );
            if ( m.matches() ) {
                ads.add ( mailAdresses[x] );
            } else {
                invalidAddresses.add ( mailAdresses[x] );
            }
        }
        String[] retAds = new String[ads.size()];
        for ( int x = 0; x < ads.size(); x++ ) {
            retAds[x] = ads.get ( x );
        }
        return retAds;
    }
}
