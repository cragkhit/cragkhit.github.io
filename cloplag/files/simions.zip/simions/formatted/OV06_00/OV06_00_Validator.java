import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.StringTokenizer;
public class OV06_00_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        String[] empty = {};
        if ( addresses == null ) {
            return empty;
        }
        ArrayList<String> validAdresses = new ArrayList<String>();
        String delim = new Character ( separator ).toString();
        StringTokenizer tokenizer = new StringTokenizer ( addresses, delim );
        while ( tokenizer.hasMoreTokens() ) {
            String current = tokenizer.nextToken();
            Matcher matcher = emailPattern.matcher ( current );
            if ( matcher.matches() ) {
                validAdresses.add ( current );
            } else {
                invalidAddresses.add ( current );
            }
        }
        return validAdresses.toArray ( empty );
    }
}
