import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class D6_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        String[] test = new String[0];
        if ( addresses == null || addresses.isEmpty() ) {
            return test;
        }
        List<String> curAddresses = new ArrayList<String>();
        List<String> validAdd = new ArrayList<String>();
        String buffer = "";
        for ( int i = 0; i < addresses.length(); i++ ) {
            if ( addresses.charAt ( i ) != separator ) {
                buffer += addresses.charAt ( i );
            } else {
                curAddresses.add ( buffer );
                buffer = "";
            }
        }
        curAddresses.add ( buffer );
        Iterator<String> it = curAddresses.iterator();
        while ( it.hasNext() ) {
            String curAdd = it.next();
            if ( !emailPattern.matcher ( curAdd ).matches() ) {
                invalidAddresses.add ( curAdd );
            } else {
                validAdd.add ( curAdd );
            }
        }
        String array[] = new String[validAdd.size()];
        if ( validAdd.isEmpty() ) {
            return array;
        } else {
            return validAdd.toArray ( array );
        }
    }
}
