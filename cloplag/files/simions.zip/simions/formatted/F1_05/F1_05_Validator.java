import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class F1_05_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        String[] a = new String[0];
        if ( addresses == null || addresses.isEmpty() ) {
            return a;
        }
        ArrayList<String> b = new ArrayList<String>();
        ArrayList<String> c = new ArrayList<String>();
        String email = "";
        for ( int i = 0; i < addresses.length(); i++ ) {
            char p = addresses.charAt ( i );
            if ( p != separator ) {
                email += p;
            } else {
                b.add ( email );
                email = "";
            }
        }
        b.add ( email );
        for ( int i = 0; i < b.size(); i++ ) {
            String x = b.get ( i );
            Matcher m = emailPattern.matcher ( x );
            if ( m.matches() ) {
                c.add ( x );
            } else {
                invalidAddresses.add ( x );
            }
        }
        String[] d = new String[c.size()];
        String[] ergebnis = c.toArray ( d );
        return ergebnis;
    }
}
