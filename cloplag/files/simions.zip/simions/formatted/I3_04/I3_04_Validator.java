import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.sun.org.apache.xerces.internal.xs.StringList;
public class I3_04_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        ArrayList<String> validEmailAddresses = new ArrayList<String>();
        if ( addresses == null || addresses.isEmpty() ) {
            return toStringArray ( validEmailAddresses );
        }
        StringTokenizer emailTokenizer = new StringTokenizer ( addresses, Character.toString ( separator ) );
        String email;
        while ( emailTokenizer.hasMoreTokens() ) {
            email = emailTokenizer.nextToken();
            if ( emailPattern.matcher ( email ).matches() ) {
                validEmailAddresses.add ( email );
            } else {
                invalidAddresses.add ( email );
            }
        }
        return toStringArray ( validEmailAddresses );
    }
    private String[] toStringArray ( List<String> stringList ) {
        String[] stringArray = new String[stringList.size()];
        for ( int i = 0; i < stringList.size(); i++ ) {
            stringArray[i] = stringList.get ( i );
        }
        return stringArray;
    }
}
