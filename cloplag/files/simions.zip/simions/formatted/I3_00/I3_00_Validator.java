import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class I3_00_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        List<String> result = new ArrayList<String>();
        if ( addresses != null && addresses.length() != 0 ) {
            String[] separatedAddresses = addresses.split ( "\\s*" + separator + "\\s*" );
            for ( String address : separatedAddresses ) {
                Matcher matcher = emailPattern.matcher ( address );
                if ( matcher.find() ) {
                    MatchResult mResult = matcher.toMatchResult();
                    if ( mResult.end() - mResult.start() == address.length() ) {
                        result.add ( address );
                    } else {
                        invalidAddresses.add ( address );
                    }
                } else {
                    invalidAddresses.add ( address );
                }
            }
        }
        return result.toArray ( new String[0] );
    }
}
