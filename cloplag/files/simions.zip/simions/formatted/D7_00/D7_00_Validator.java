import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class D7_00_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "^[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+$" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.length() == 0 )
            return new String[] {};
        String[] adrArray = Pattern.compile ( "\\s*" + separator + "\\s*" ).split ( addresses );
        List<String> list = new ArrayList<String>();
        for ( String adr : adrArray ) {
            Matcher m = emailPattern.matcher ( adr );
            if ( adr != null ) {
                if ( m.matches() ) {
                    list.add ( adr );
                } else {
                    invalidAddresses.add ( adr );
                }
            }
        }
        return list.toArray ( new String[] {} );
    }
}
