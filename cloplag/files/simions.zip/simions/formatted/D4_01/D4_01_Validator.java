import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.StringTokenizer;
public class D4_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.isEmpty() ) {
            return new String[0];
        }
        StringTokenizer tokenizer = new StringTokenizer ( addresses, Character.toString ( separator ) );
        List<String> resultList = new ArrayList<String> ( tokenizer.countTokens() );
        while ( tokenizer.hasMoreTokens() ) {
            String address = tokenizer.nextToken();
            address.trim();
            if ( emailPattern.matcher ( address ).matches() ) {
                resultList.add ( address );
            } else {
                invalidAddresses.add ( address );
            }
        }
        String[] result = new String[resultList.size()];
        resultList.toArray ( result );
        return result;
    }
}
