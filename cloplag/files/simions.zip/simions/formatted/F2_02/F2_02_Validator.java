import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class F2_02_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        String[] valid = new String[0];
        int counter = 0;
        String adds = addresses;
        while ( ! ( adds == "" ) && ! ( adds == null ) ) {
            int sep = adds.indexOf ( separator );
            String mail;
            if ( sep == -1 ) {
                mail = adds;
                adds = "";
            } else {
                mail = adds.substring ( 0, sep );
                adds = adds.substring ( sep + 1, adds.length() );
                adds = adds.trim();
            }
            mail = mail.trim();
            Matcher m = emailPattern.matcher ( mail );
            boolean b = m.matches();
            if ( b && mail != "" ) {
                if ( counter == valid.length ) {
                    valid = extendCapacity ( valid );
                }
                valid[counter] = mail;
                counter++;
            } else {
                invalidAddresses.add ( mail );
            }
        }
        return valid;
    }
    public String[] extendCapacity ( String[] input ) {
        String[] output = new String[input.length + 1];
        for ( int i = 0; i < input.length; i++ ) {
            output[i] = input[i];
        }
        return output;
    }
    public static void printArray ( Object[] input ) {
        for ( Object a : input ) {
            System.out.print ( "[" + a + "] - " );
        }
        System.out.println();
    }
}
