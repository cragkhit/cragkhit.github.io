import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class I3_02_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        System.out.println ( "!!!!!!!!!!!!!!!!!!!\n" + addresses );
        if ( addresses == null || addresses.isEmpty() ) {
            return new String[0];
        }
        List<String> addressList = new ArrayList<String>();
        StringTokenizer st = new StringTokenizer ( addresses, String.valueOf ( separator ) );
        while ( st.hasMoreTokens() ) {
            String token = st.nextToken();
            if ( testEmail ( token ) ) {
                addressList.add ( token );
            } else {
                invalidAddresses.add ( token );
            }
        }
        String[] stringArray = new String[addressList.size()];
        for ( int i = 0; i < addressList.size(); i++ ) {
            stringArray[i] = addressList.get ( i );
        }
        return stringArray;
    }
    public boolean testEmail ( String email ) {
        Matcher m = emailPattern.matcher ( email );
        return m.matches();
    }
}
