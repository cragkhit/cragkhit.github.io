import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class D2_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        ArrayList<String> result = new ArrayList<String>();
        String[] res_array = {};
        if ( addresses == null ) {
            return res_array;
        }
        if ( addresses.length() == 0 ) {
            return res_array;
        }
        String[] addresses_array = addresses.split ( Pattern.quote ( separator + "" ) );
        for ( String address : addresses_array ) {
            if ( this.emailPattern.matcher ( address.trim() ).matches() ) {
                result.add ( address );
            } else {
                invalidAddresses.add ( address );
            }
        }
        return result.toArray ( res_array );
    }
}
