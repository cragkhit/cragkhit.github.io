import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class D1_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        if ( ( addresses == null ) || ( addresses.equals ( "" ) ) ) return new String[] {};
        int anz = 0;
        for ( int i = 0; i < addresses.length(); i++ ) {
            if ( ( addresses.charAt ( i ) == ( separator ) ) ) {
                anz++;
            }
        }
        String[] adr = new String[ ( int ) ( anz + 1 )];
        int i = 0;
        while ( !addresses.equals ( "" ) ) {
            if ( !addresses.contains ( Character.toString ( separator ) ) ) {
                adr[i] = addresses;
                addresses = "";
            } else {
                adr[i] = addresses.substring ( 0, addresses.indexOf ( separator ) );
                addresses = addresses.substring ( addresses.indexOf ( separator ) + 1 );
            }
            i++;
        }
        int validAdr = 0;
        for ( int j = 0; j < adr.length; j++ ) {
            Matcher m = emailPattern.matcher ( adr[j] );
            if ( m.matches() ) {
                validAdr++;
            }
        }
        String[] validAddresses = new String[validAdr];
        i = 0;
        for ( int j = 0; j < adr.length; j++ ) {
            Matcher m = emailPattern.matcher ( adr[j] );
            if ( m.matches() ) {
                validAddresses[i] = adr[j];
                i++;
            } else {
                invalidAddresses.add ( adr[j] );
            }
        }
        return validAddresses;
    }
}
