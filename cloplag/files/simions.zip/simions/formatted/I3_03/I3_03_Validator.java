import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
public class I3_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null ) {
            return new String[0];
        }
        List<String> validMails = new ArrayList<String>();
        StringTokenizer tokens = new StringTokenizer ( addresses.trim(), String.valueOf ( separator ) );
        while ( tokens.hasMoreTokens() ) {
            String mail = tokens.nextToken().trim();
            if ( emailPattern.matcher ( mail ).matches() ) {
                validMails.add ( mail );
            } else {
                invalidAddresses.add ( mail );
            }
        }
        String[] validMailsArr = new String[validMails.size()];
        validMails.toArray ( validMailsArr );
        return validMailsArr;
    }
}
