import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class OV3_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        String sep = new String();
        if ( separator == '\\' ) {
            sep = "\\\\";
        } else {
            sep = Character.toString ( separator );
        }
        if ( addresses == null || addresses.isEmpty() ) {
            return new String[0];
        }
        List<String> valid = new ArrayList<String>();
        String[] mail = addresses.split ( sep );
        for ( int i = 0; i < mail.length; i++ ) {
            if ( mail[i].equals ( sep ) ) {
                continue;
            }
            if ( analyseEmail ( mail[i] ) ) {
                valid.add ( mail[i] );
            } else {
                invalidAddresses.add ( mail[i] );
            }
        }
        return valid.toArray ( new String[0] );
    }
    public boolean analyseEmail ( String mail ) {
        Matcher m = emailPattern.matcher ( mail );
        return m.matches();
    }
}
