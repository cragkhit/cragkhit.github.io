import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class F4_02_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        List<String> addrs = new ArrayList<String>();
        if ( addresses == null ) {
            return addrs.toArray ( new String[0] );
        }
        int lastsep = -1;
        for ( int i = 0; i < addresses.length(); i++ ) {
            if ( addresses.charAt ( i ) == separator ) {
                String addr = addresses.substring ( lastsep + 1, i ).trim();
                if ( validateAddress ( addr ) ) {
                    addrs.add ( addr );
                } else if ( addr.length() > 0 ) {
                    invalidAddresses.add ( addr );
                }
                lastsep = i;
            }
        }
        String addr = addresses.substring ( lastsep + 1, addresses.length() ).trim();
        if ( validateAddress ( addr ) ) {
            addrs.add ( addr );
        } else if ( addr.length() > 0 ) {
            invalidAddresses.add ( addr );
        }
        return addrs.toArray ( new String[0] );
    }
    private boolean validateAddress ( String addr ) {
        return emailPattern.matcher ( addr ).matches();
    }
}
