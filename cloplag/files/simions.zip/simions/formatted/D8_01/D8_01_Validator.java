import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class D8_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null ) {
            return new String[0];
        }
        if ( addresses.equals ( "" ) ) {
            return new String[0];
        }
        List<String> gueltig = new ArrayList<String>();
        String sep = String.valueOf ( separator );
        if ( separator == '\\' ) {
            sep = "\\\\";
        }
        String[] result1 = addresses.split ( sep );
        System.out.println ( Arrays.toString ( result1 ) );
        for ( String adr : result1 ) {
            Matcher m = emailPattern.matcher ( adr );
            boolean ergebnis = m.matches();
            if ( ergebnis ) {
                gueltig.add ( adr );
            } else {
                invalidAddresses.add ( adr );
            }
        }
        return gueltig.toArray ( new String[0] );
    }
}
