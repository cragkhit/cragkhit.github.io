import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class I1_02_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.equals ( "" ) ) {
            return new String[0];
        }
        ArrayList<String> emailListe = new ArrayList<String>();
        int trenneralt = 0;
        while ( addresses.indexOf ( separator, trenneralt ) != -1 ) {
            int trennerneu = addresses.indexOf ( separator, trenneralt );
            emailListe.add ( addresses.substring ( trenneralt, trennerneu ) );
            trenneralt = trennerneu + 1;
        }
        emailListe.add ( addresses.substring ( trenneralt, addresses.length() ) );
        ArrayList<String> hilfslist = new ArrayList<String>();
        for ( String entry : emailListe ) {
            if ( entry.matches ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" ) ) {
                hilfslist.add ( entry );
            } else {
                invalidAddresses.add ( entry );
            }
        }
        String[] ergebnis = new String[hilfslist.size()];
        return hilfslist.toArray ( ergebnis );
    }
}
