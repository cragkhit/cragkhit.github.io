import java.util.ArrayList;
import java.util.Set;
import java.util.regex.Pattern;
public class M3_05_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.trim().equals ( "" ) ) return new String[] {};
        String[] addressesArr = addresses.split ( Pattern.quote ( String.valueOf ( separator ) ) );
        ArrayList<String> validAddresses = new ArrayList<String>();
        for ( String address : addressesArr ) {
            address = address.trim();
            if ( address.matches ( emailPattern.toString() ) == true ) {
                validAddresses.add ( address );
            } else {
                invalidAddresses.add ( address );
            }
        }
        return validAddresses.toArray ( new String[validAddresses.size()] );
    }
}
