import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class D6_06_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( null == addresses || addresses.equals ( "" ) ) {
            return new String[0];
        }
        String emailRegExp = "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+";
        String[] emails = addresses.split ( Pattern.quote ( "" + separator ) );
        ArrayList<String> gueltig = new ArrayList<String>();
        for ( int i = 0; i < emails.length; i++ ) {
            String s = emails[i].trim();
            if ( s.matches ( emailRegExp ) ) {
                gueltig.add ( s );
            } else {
                invalidAddresses.add ( s );
            }
        }
        return gueltig.toArray ( new String[0] );
    }
}
