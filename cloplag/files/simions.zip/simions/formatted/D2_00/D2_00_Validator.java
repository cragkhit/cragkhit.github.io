import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class D2_00_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        if ( addresses == null ) return new String[] {};
        String[] addressArray = addresses.split ( "\\Q" + separator + "\\E" );
        List<String> validAddresses = new ArrayList<String>();
        for ( String s : addressArray ) {
            if ( emailPattern.matcher ( s ).matches() ) {
                validAddresses.add ( s );
            } else if ( !s.equals ( "" ) ) {
                invalidAddresses.add ( s );
            }
        }
        return validAddresses.toArray ( new String[] {} );
    }
}
