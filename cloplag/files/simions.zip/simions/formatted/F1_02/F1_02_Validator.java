import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.*;
public class F1_02_Validator {
    public boolean isWort ( char a ) {
        boolean t = true;
        if ( ! (	( int ) a >= 48 && ( int ) a <= 57 ||
                    ( int ) a >= 65 && ( int ) a <=  90 ||
                    ( int ) a >= 97 && ( int ) a <=  122 ||
                    ( int ) a == 46
               ) ) {
            t = false;
        }
        return t;
    }
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null ) {
            return new String[0];
        }
        if ( addresses.isEmpty() ) {
            return new String[0];
        }
        String[] addrlist = addresses.split ( Pattern.quote ( Character.toString ( separator ) ) );
        ArrayList<String> result = new ArrayList();
        for ( String tempaddr : addrlist ) {
            Boolean[] bewertung = {false, false, false};
            char[] tempaddrarr = tempaddr.toCharArray();
            if ( isWort ( tempaddrarr[0] ) ) {
                bewertung[0] = true;
            }
            if ( tempaddrarr[tempaddrarr.length - 1] == '@' ) {
                bewertung[0] = false;
            }
            if ( tempaddrarr[tempaddrarr.length - 1] == '.' ) {
                bewertung[0] = false;
            }
            for ( int i = 1; i < tempaddrarr.length; i = i + 1 ) {
                boolean temp = false;
                if ( isWort ( tempaddrarr[i] ) ) {
                    temp = true;
                }
                if ( tempaddrarr[i] == '@' && !bewertung[1] ) {
                    bewertung[1] = true;
                    temp = true;
                }
                if ( bewertung[1] && tempaddrarr[i] == '.' ) {
                    bewertung[2] = true;
                }
                if ( !temp ) {
                    bewertung[0] = false;
                }
            }
            if ( bewertung[0] && bewertung[1] && bewertung[2] ) {
                result.add ( tempaddr );
            } else {
                invalidAddresses.add ( tempaddr );
            }
        }
        return result.toArray ( new String[0] );
    }
}
