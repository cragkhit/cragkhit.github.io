import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
public class D4_08_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        List<String> validAddresses = new ArrayList<String>();
        if ( ! ( addresses == null ) ) {
            StringTokenizer st = new StringTokenizer ( addresses, String.valueOf ( separator ) );
            String address;
            while ( st.hasMoreTokens() ) {
                address = st.nextToken().trim();
                if ( emailPattern.matcher ( address ).matches() ) {
                    validAddresses.add ( address );
                } else {
                    if ( ! ( address.isEmpty() ) ) {
                        invalidAddresses.add ( address );
                    }
                }
            }
        }
        return validAddresses.toArray ( new String[0] );
    }
}
