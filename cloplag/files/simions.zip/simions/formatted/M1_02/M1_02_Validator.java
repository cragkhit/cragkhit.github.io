import java.util.ArrayList;
import java.util.Set;
import java.util.regex.Pattern;
public class M1_02_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        ArrayList<String> validAdresses = new ArrayList<String>();
        if ( addresses != "" && addresses != null ) {
            CharSequence[] adresses2 = addresses.split ( Pattern.quote ( String.valueOf ( separator ) ) );
            for ( CharSequence e : adresses2 ) {
                if ( emailPattern.matcher ( e ).matches() ) {
                    validAdresses.add ( e.toString() );
                } else {
                    invalidAddresses.add ( e.toString() );
                }
            }
        }
        String[] returnValidAdresses = new String[validAdresses.size()];
        for ( int i = 0; i < validAdresses.size(); i++ ) {
            returnValidAdresses[i] = validAdresses.get ( i );
        }
        return returnValidAdresses;
    }
}
