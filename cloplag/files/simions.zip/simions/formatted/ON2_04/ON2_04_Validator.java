import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class ON2_04_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        if ( addresses == null ) {
            return new String[] {};
        }
        if ( invalidAddresses == null ) {
            invalidAddresses = new HashSet<String>();
        }
        if ( addresses.equals ( "" ) ) {
            return new String[] {};
        }
        String[] addressArray = addresses.split ( Pattern.quote ( Character.toString ( separator ) ) );
        for ( int i = 0; i < addressArray.length; i++ ) {
            if ( addressArray[i] != "" ) {
                if ( ! validateAddress ( addressArray[i] ) ) {
                    invalidAddresses.add ( addressArray[i] );
                }
            }
        }
        String[] output = new String[addressArray.length - invalidAddresses.size()];
        for ( int i = 0, j = 0; i < addressArray.length; i++ ) {
            if ( ! invalidAddresses.contains ( addressArray[i] ) ) {
                output[j] = addressArray[i];
                j++;
            }
        }
        return output;
    }
    private boolean validateAddress ( String address ) {
        if ( address != null ) {
            Matcher m = emailPattern.matcher ( address );
            return m.matches();
        }
        return false;
    }
}
