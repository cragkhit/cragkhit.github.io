import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Arrays;
public class ON5_00_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null ) {
            return new String[0];
        }
        if ( addresses.equals ( "" ) ) {
            return new String[0];
        }
        if ( addresses.length() < 3 ) {
            invalidAddresses.add ( addresses );
            return new String[0];
        }
        if ( separator == ( '\\' ) ) {
            addresses = addresses.replace ( '\\', '/' );
            separator = '/';
        }
        String[] mails = addresses.split ( String.valueOf ( separator ) );
        int i = 0;
        for ( String mail : mails ) {
            Matcher m = emailPattern.matcher ( mail );
            if ( !m.matches() ) {
                if ( ! ( mail == "" ) ) {
                    invalidAddresses.add ( mail );
                }
                mails[i] = null;
            }
            i++;
        }
        for ( i = 0; i < mails.length; i++ ) {
            if ( mails[i] == null ) {
                for ( int j = i; j < mails.length - 1; j++ ) {
                    mails[j] = mails[j + 1];
                }
            }
        }
        for ( i = 0; i < mails.length; i++ ) {
            if ( mails[i] == null ) {
                break;
            }
        }
        String[] returnArray = Arrays.copyOf ( mails, i );
        return returnArray;
    }
}
