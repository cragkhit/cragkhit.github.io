import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class F5_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.length() == 0 ) {
            return new String[0];
        } else if ( addresses.length() == 1 ) {
            invalidAddresses.add ( addresses );
            return new String[0];
        } else {
            String[] arrayOfAddresses;
            if ( separator != '\\' ) {
                arrayOfAddresses = addresses.split ( String.valueOf ( separator ) );
            } else {
                arrayOfAddresses = addresses.split ( "\\\\" );
            }
            return validateEmailAddresses ( arrayOfAddresses, separator,
                                            invalidAddresses );
        }
    }
    public String[] validateEmailAddresses ( String[] addresses, char separator,
            Set<String> invalidAddresses ) {
        ArrayList<String> validAddresses = new ArrayList<String> ( 0 );
        String[] result = new String[0];
        for ( String s : addresses ) {
            if ( Pattern.matches ( emailPattern.toString(), s ) ) {
                validAddresses.ensureCapacity ( validAddresses.size() + 1 );
                validAddresses.add ( s );
            } else {
                invalidAddresses.add ( s );
            }
        }
        result = new String[validAddresses.size()];
        for ( int i = 0; i <= validAddresses.size() - 1; i++ ) {
            result[i] = validAddresses.get ( i );
        }
        return result;
    }
}
