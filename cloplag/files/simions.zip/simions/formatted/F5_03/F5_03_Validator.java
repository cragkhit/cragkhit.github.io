import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class F5_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || invalidAddresses == null ) {
            return new String[0];
        }
        String bla = String.valueOf ( separator );
        if ( bla.equals ( "\\" ) ) {
            bla = "\\\\";
        }
        String[] MailadressenString = addresses.split ( bla );
        for ( int i = 0; i < MailadressenString.length; i++ ) {
            String s = MailadressenString[i];
            MailadressenString[i] = s.trim();
        }
        List<String> lsv = new ArrayList<String>();
        for ( int i = 0; i < MailadressenString.length; i++ ) {
            String s = MailadressenString[i];
            if ( s.isEmpty() )
                ;
            else if ( emailPattern.matcher ( s ).matches() ) {
                lsv.add ( s );
            } else {
                invalidAddresses.add ( s );
            }
        }
        return lsv.toArray ( new String[0] );
    }
}
