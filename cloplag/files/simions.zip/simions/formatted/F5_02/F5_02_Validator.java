import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class F5_02_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        List<String> validemails = new ArrayList <String>();
        String[] empty = {};
        if ( addresses == null ) {
            return empty;
        }
        if ( invalidAddresses == null ) {
            return empty;
        }
        if ( addresses.isEmpty() ) {
            return empty;
        }
        while ( addresses.contains ( Character.toString ( separator ) ) ) {
            if ( !addresses.isEmpty() ) {
                addresses = addresses.trim();
            }
            String email = addresses.substring ( 0, addresses.indexOf ( separator ) );
            if ( email.trim().matches ( emailPattern.pattern() ) ) {
                validemails.add ( email.trim() );
            } else {
                invalidAddresses.add ( email.trim() );
            }
            addresses = addresses.substring ( addresses.indexOf ( separator ) + 1, addresses.length() );
        }
        if ( !addresses.isEmpty() ) {
            addresses = addresses.trim();
        }
        if ( addresses.trim().matches ( emailPattern.pattern() ) ) {
            validemails.add ( addresses.trim() );
        } else {
            invalidAddresses.add ( addresses.trim() );
        }
        String[] a =  validemails.toArray ( new String [0] );
        return a;
    }
}
