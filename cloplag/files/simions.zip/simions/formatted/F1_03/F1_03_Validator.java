import java.util.Set;
import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class F1_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        ArrayList<String> return_emails = new ArrayList<String>();
        String[] unchecked_emails = explode ( separator, addresses );
        for ( String single_email : unchecked_emails ) {
            if ( !invalidAddresses.contains ( single_email ) && single_email != "" ) {
                Matcher matcher = emailPattern.matcher ( single_email );
                if ( matcher.matches() ) {
                    return_emails.add ( single_email );
                } else {
                    invalidAddresses.add ( single_email );
                }
            }
        }
        String[] return_array = new String[return_emails.size()];
        for ( int i = 0; i < return_emails.size(); i++ ) {
            return_array[i] = return_emails.get ( i );
        }
        return return_array;
    }
    private String[] explode ( Character delimiter, String string ) {
        if ( string != null && string.length() != 0 ) {
            String delimiter2 = delimiter.toString();
            if ( delimiter2.equals ( "\\" ) ) {
                delimiter2 = "\\\\";
            }
            String[] return_string_array = string.split ( delimiter2 );
            for ( String single_string : return_string_array ) {
                single_string.trim();
            }
            return return_string_array;
        } else {
            return new String[0];
        }
    }
}
