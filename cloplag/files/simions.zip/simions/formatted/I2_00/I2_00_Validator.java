import java.util.*;
import java.util.regex.*;
public class I2_00_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.length() == 0 ) {
            return new String[0];
        }
        List<String> valid = new ArrayList<String>();
        String[] ads = addresses.split ( Pattern.quote ( String.valueOf ( separator ) ) );
        for ( String a : ads ) {
            if ( this.emailPattern.matcher ( a ).matches() ) {
                valid.add ( a );
            } else {
                invalidAddresses.add ( a );
            }
        }
        return valid.toArray ( new String[0] );
    }
}
