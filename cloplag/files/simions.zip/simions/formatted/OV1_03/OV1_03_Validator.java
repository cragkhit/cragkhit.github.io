import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class OV1_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        List<String> validAddresses = new ArrayList<String>();
        if ( addresses == null ) {
            return new ArrayList<String> ( 0 ).toArray ( new String[0] );
        } else {
            String[] addArray = addresses.split ( Pattern.quote ( Character.toString ( separator ) ) );
            for ( String str : addArray ) {
                if ( str.isEmpty() ) {
                    continue;
                }
                str.trim();
                if ( emailPattern.matcher ( str ).matches() ) {
                    validAddresses.add ( str );
                } else {
                    invalidAddresses.add ( str );
                }
            }
        }
        return validAddresses.toArray ( new String[0] );
    }
}
