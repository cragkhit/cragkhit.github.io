import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class D2_04_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.equals ( "" ) ) {
            return new String[0];
        }
        String[] adressen;
        if ( separator == '\\' ) {
            adressen = addresses.split ( "\\\\" );
        } else {
            adressen = addresses.split ( "" + separator );
        }
        List<String> ergebnis = new LinkedList<String>();
        for ( String adresse : adressen ) {
            boolean beginntMitLeerzeichen;
            do {
                beginntMitLeerzeichen = adresse.startsWith ( " " );
                if ( beginntMitLeerzeichen ) {
                    adresse = adresse.substring ( 1 );
                }
            } while ( beginntMitLeerzeichen );
            boolean endedMitLeerzeichen;
            do {
                endedMitLeerzeichen = adresse.endsWith ( " " );
                if ( endedMitLeerzeichen ) {
                    adresse = adresse.substring ( 0, adresse.length() - 1 );
                }
            } while ( endedMitLeerzeichen );
            Matcher m = emailPattern.matcher ( adresse );
            if ( m.matches() ) {
                ergebnis.add ( adresse );
            } else {
                invalidAddresses.add ( adresse );
            }
        }
        String[] erg = new String[ergebnis.size()];
        int i = 0;
        for ( String e : ergebnis ) {
            erg[i] = e;
            i++;
        }
        return erg;
    }
}
