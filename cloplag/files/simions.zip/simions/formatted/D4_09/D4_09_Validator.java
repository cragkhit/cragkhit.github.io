import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class D4_09_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        List<String> ausgabe = new ArrayList<String>();
        String sep = "" + separator;
        if ( addresses == null || addresses.isEmpty() )
            return new String [] {};
        else {
            int x = addresses.indexOf ( sep );
            if ( x == -1 ) {
                if ( addresses.matches ( emailPattern.toString() ) ) {
                    ausgabe.add ( addresses );
                } else {
                    invalidAddresses.add ( addresses );
                }
            }
            else {
                String [] adr  = addresses.split ( "\\" + sep );
                for ( int i = 0; i < adr.length; i++ ) {
                    if ( adr[i].matches ( emailPattern.toString() ) ) {
                        ausgabe.add ( adr[i] );
                    } else {
                        invalidAddresses.add ( adr[i] );
                    }
                }
            }
            String[] result = new String[ausgabe.size()];
            ausgabe.toArray ( result );
            return result;
        }
    }
}
