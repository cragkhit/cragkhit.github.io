import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class F5_00_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        String[] r = new String[0];
        String[] a;
        List<String> list = new ArrayList<String>();
        if ( addresses == null || invalidAddresses == null ) {
            return r;
        }
        String sep = String.valueOf ( separator );
        if ( sep.equals ( "\\" ) ) {
            sep = "\\\\";
        }
        a = addresses.split ( sep );
        for ( String s : a ) {
            s = s.trim();
        }
        for ( String s : a )
            if ( emailPattern.matcher ( s ).matches() ) {
                list.add ( s );
            } else if ( !s.isEmpty() ) {
                invalidAddresses.add ( s );
            }
        return r = list.toArray ( new String[0] );
    }
}
