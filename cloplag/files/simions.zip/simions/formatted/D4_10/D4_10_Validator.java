import java.util.ArrayList;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class D4_10_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null ) {
            return new String[0];
        } else if ( addresses.isEmpty() ) {
            return new String[0];
        }
        String spliter;
        if ( separator == '\\' ) {
            spliter = "\\\\";
        } else {
            spliter = String.valueOf ( separator );
        }
        String[] emails = addresses.split ( "w*" + spliter + "w*" );
        ArrayList<String> result = new ArrayList<String>();
        for ( int i = 0; i < emails.length; i++ ) {
            Matcher m = emailPattern.matcher ( emails[i].subSequence ( 0, emails[i].length() ) );
            if ( m.matches() ) {
                result.add ( emails[i] );
            } else {
                invalidAddresses.add ( emails[i] );
            }
        }
        String[] res = new String[result.size()];
        return result.toArray ( res );
    }
}
