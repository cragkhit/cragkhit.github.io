import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class D6_05_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.length() == 0 ) {
            return new String[0];
        }
        String[] mails = addresses.split ( Pattern.quote ( Character.toString ( separator ) ) );
        ArrayList<String> retoure = new ArrayList<String>();
        for ( int i = 0; i < mails.length; i++ ) {
            mails[i] = mails[i].trim();
            if ( emailPattern.matcher ( mails[i] ).matches() ) {
                retoure.add ( mails[i] );
            } else {
                invalidAddresses.add ( mails[i] );
            }
        }
        return retoure.toArray ( new String[0] );
    }
}
