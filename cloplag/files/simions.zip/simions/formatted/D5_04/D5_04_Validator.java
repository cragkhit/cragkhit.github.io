import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class D5_04_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.isEmpty()	) {
            return new String[0];
        }
        List<String> result = new ArrayList<String>();
        int z = 0;
        for ( int i = 0; i < addresses.length(); i++ ) {
            if ( i == addresses.length() - 1 )	{
                result.add ( addresses.substring ( z, i + 1 ) );
            }
            if ( addresses.charAt ( i ) == separator ) {
                result.add ( addresses.substring ( z, i ) );
                z = i + 1;
            }
        }
        Matcher m;
        for ( int i = 0; i < result.size(); i++ ) {
            m = emailPattern.matcher ( result.get ( i ) );
            if ( !m.matches() ) {
                invalidAddresses.add ( result.get ( i ) );
            }
        }
        result.removeAll ( invalidAddresses );
        String[] s = new String [result.size()];
        result.toArray ( s );
        return s;
    }
}
