import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class OV2_02_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.length() == 0 ) {
            return new String[0];
        }
        List<String> valid = new ArrayList<String>();
        char[] temp = {'\\', separator};
        String[] addressen = addresses.split ( new String ( temp ) );
        String email = "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+";
        for ( String x : addressen ) {
            x = x.trim();
            if ( x.matches ( email ) ) {
                valid.add ( x );
            } else {
                invalidAddresses.add ( x );
            }
        }
        return valid.toArray ( new String[0] );
    }
}
