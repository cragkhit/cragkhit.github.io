import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class ON5_02_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses != null ) {
            addresses = addresses.replace ( Character.toString ( separator ), "\\\\" );
            String[] TempSplittedAddresses = addresses.split ( "\\\\" );
            List<String> validAddresses = new ArrayList<String>();
            for ( String address : TempSplittedAddresses ) {
                Matcher m = emailPattern.matcher ( address );
                if ( m.matches() ) {
                    validAddresses.add ( address );
                } else if ( !address.equals ( "" ) ) {
                    invalidAddresses.add ( address );
                }
            }
            return validAddresses.toArray ( new String[0] );
        } else {
            return new String[0];
        }
    }
}
