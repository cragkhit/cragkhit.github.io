import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class M2_04_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses == "" ) {
            return new String[] {};
        }
        addresses = addresses.replace ( separator, ',' );
        ArrayList<String> result = new ArrayList();
        String[] adressen = addresses.split ( "," );
        for ( int i = 0; i < adressen.length; i++ ) {
            if ( isValid ( adressen[i] ) ) {
                result.add ( adressen[i] );
            } else {
                invalidAddresses.add ( adressen[i] );
            }
        }
        return 	result.toArray ( new String[] {} );
    }
    private boolean isValid ( String str ) {
        return emailPattern.matches ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+", str );
    }
}
