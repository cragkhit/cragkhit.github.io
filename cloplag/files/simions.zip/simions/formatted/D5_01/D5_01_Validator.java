import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class D5_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        List<String> Ans = new ArrayList<String>();
        int cnt = 0;
        if ( addresses == null || addresses.length() == 0 ) {
            invalidAddresses.clear();
            return new String[0];
        }
        String[] email = addresses.split ( Pattern.quote ( Character.toString ( separator ) ) );
        Matcher m;
        boolean test;
        for ( String it : email ) {
            m = emailPattern.matcher ( it );
            test = m.matches();
            if ( test ) {
                Ans.add ( it );
                ++ cnt;
            } else {
                invalidAddresses.add ( it );
            }
        }
        String[] result = new String[cnt];
        return Ans.toArray ( result );
    }
}
