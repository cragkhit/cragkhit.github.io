import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class D3_04_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( ( addresses == null ) || addresses.isEmpty() ) {
            return new String[0];
        }
        List<String> res = new ArrayList<String>();
        String safesep = literalize ( "" + separator );
        for ( String address : addresses.split ( safesep ) ) {
            if ( emailPattern.matcher ( address ).matches() ) {
                res.add ( address );
            } else {
                invalidAddresses.add ( address );
            }
        }
        String[] prototype = new String[0];
        return res.toArray ( prototype );
    }
    private String literalize ( String separator ) {
        String backslashpattern = "[\\\\]";
        String res = separator.replaceAll ( backslashpattern, "[\\\\\\\\]" );
        return res;
    }
}
