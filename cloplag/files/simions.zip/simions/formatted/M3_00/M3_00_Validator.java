import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class M3_00_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.isEmpty() ) {
            return new String[0];
        }
        List<String> validAddresses = new ArrayList<String>();
        for ( String sample : addresses.split ( Pattern.quote ( new String ( new char[] { separator } ) ) ) ) {
            if ( emailPattern.matcher ( sample ).matches() ) {
                validAddresses.add ( sample );
            } else {
                invalidAddresses.add ( sample );
            }
        }
        return validAddresses.toArray ( new String[0] );
    }
}
