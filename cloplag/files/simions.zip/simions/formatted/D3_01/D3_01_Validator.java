import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.AbstractCollection;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class D3_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        ArrayList<String> validAddresses = new ArrayList<String>();
        if ( addresses == null || addresses.length() == 0 ) {
            return new String[0];
        }
        String s = String.valueOf ( separator );
        StringBuffer b = new StringBuffer ( s );
        for ( int i = 0; i < b.length(); i++ ) {
            if ( b.charAt ( i ) == '\\' ) {
                b.insert ( i++, '\\' );
            }
        }
        String sep = b.toString();
        String[] ad = addresses.split ( sep );
        String address;
        Matcher m;
        for ( int i = 0; i < ad.length; i++ ) {
            address = ad[i].replaceAll ( "\\\\", "\\\\\\" );
            m = emailPattern.matcher ( address );
            if ( m.matches() ) {
                validAddresses.add ( address );
            } else {
                invalidAddresses.add ( address );
            }
        }
        return validAddresses.toArray ( new String[0] );
    }
}
