import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class OV06_02_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == "" || addresses == null ) {
            return new String[] {};
        }
        List<String> out = new ArrayList<String>();
        String[] addr = addresses.split ( "\\" + Character.toString ( separator ) );
        for ( String tmp : addr ) {
            if ( emailPattern.matcher ( tmp.trim() ).matches() ) {
                out.add ( tmp );
            } else {
                invalidAddresses.add ( tmp );
            }
        }
        return out.toArray ( new String[] {} );
    }
}
