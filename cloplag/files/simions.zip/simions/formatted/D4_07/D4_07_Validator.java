import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class D4_07_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        String[] separatedAddresses;
        ArrayList<String> validAddresses = new ArrayList<String>();
        if ( addresses == null || addresses.isEmpty() )
            return new String[] {};
        else {
            separatedAddresses = split ( addresses, separator );
            for ( String s : separatedAddresses ) {
                Matcher m = emailPattern.matcher ( s );
                if ( m.matches() ) {
                    validAddresses.add ( s.trim() );
                } else {
                    invalidAddresses.add ( s.trim() );
                }
            }
        }
        String[] result = validAddresses.toArray ( new String[] {} );
        return result;
    }
    public String[] split ( String addresses, char separator ) {
        return addresses.split ( Pattern.quote ( new String ( new char[] {separator} ) ), 0 );
    }
}
