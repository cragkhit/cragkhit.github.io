import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.StringTokenizer;
public class I1_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses == "" || invalidAddresses == null ) {
            String[] str = {};
            return str;
        }
        StringTokenizer tokenizer = new StringTokenizer ( addresses, String.valueOf ( separator ) );
        List<String> l = new ArrayList<String>();
        Matcher m;
        while ( tokenizer.hasMoreElements() ) {
            String s = tokenizer.nextToken();
            m = emailPattern.matcher ( s );
            if ( m.matches() ) {
                l.add ( s );
            } else {
                invalidAddresses.add ( s );
            }
        }
        String[] strArray = new String[l.size()];
        return l.toArray ( strArray );
    }
}
