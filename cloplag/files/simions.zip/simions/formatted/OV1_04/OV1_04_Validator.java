import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class OV1_04_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        ArrayList<String> validAddresses = new ArrayList<String>();
        if ( addresses != null && addresses != "" )
            for ( String address :
                    addresses.split ( Pattern.quote ( Character.toString ( separator ) ) ) )
                if ( emailPattern.matcher ( address ).matches() ) {
                    validAddresses.add ( address );
                } else {
                    invalidAddresses.add ( address );
                }
        String[] java_is_crap = new String[validAddresses.size()];
        return validAddresses.toArray ( java_is_crap );
    }
}
