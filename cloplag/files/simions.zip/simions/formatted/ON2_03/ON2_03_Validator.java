import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class ON2_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        String[] ad = null;
        ArrayList<String> validAdresses = new ArrayList<String>();
        int valid = 0;
        try {
            if ( addresses.isEmpty() | String.valueOf ( separator ).isEmpty() ) {
                return new String[] {};
            }
        } catch ( NullPointerException ex ) {
            return new String[] {};
        }
        ad = addresses.split ( Pattern.quote ( Character.toString ( separator ) ) );
        for ( int i = 0; i < ad.length; i++ ) {
            ad[i].replaceAll ( " ", "" );
            if ( ad[i].matches ( emailPattern.pattern() ) ) {
                validAdresses.add ( ad[i] );
                valid++;
            } else {
                invalidAddresses.add ( ad[i] );
            }
        }
        if ( validAdresses.isEmpty() ) {
            return new String[] {};
        }
        String[] result = new String[valid];
        for ( int j = 0; j < result.length; j++ ) {
            result[j] = validAdresses.get ( j );
        }
        return result;
    }
}
