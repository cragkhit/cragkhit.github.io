import java.util.ArrayList;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class M3_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || invalidAddresses == null || addresses.equals ( new String ( "" ) ) ) {
            return new String[0];
        }
        ArrayList<String> result = new ArrayList<String>();
        String[] addresslist = addresses.split ( Character.toString ( separator ).replace ( "\\", "\\\\" ) );
        for ( String address : addresslist )
            if ( isValidEmailAddress ( address ) ) {
                result.add ( address );
            } else {
                invalidAddresses.add ( address );
            }
        return result.toArray ( new String[0] );
    }
    private boolean isValidEmailAddress ( String address ) {
        if ( address == null ) {
            return false;
        }
        Matcher m = emailPattern.matcher ( address.trim() );
        return ( m.find() ) ? m.end() == address.trim().length() && m.start() == 0 : false;
    }
}
