import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Iterator;
public class ON5_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        String [] eArrayString = {};
        if ( addresses == null || addresses.equals ( "" ) ) {
            return eArrayString;
        }
        String [] result = new String[getAnzahlAdressen ( addresses, separator )];
        List<String> validAddresses = new ArrayList<String>();
        int j = 0;
        for ( int i = 0; i < addresses.length(); i++ ) {
            if ( addresses.charAt ( i ) != ' ' ) {
                if ( addresses.charAt ( i ) == separator ) {
                    j++;
                } else if ( result[j] == null ) {
                    result[j] = Character.toString ( addresses.charAt ( i ) );
                } else {
                    result[j] += addresses.charAt ( i );
                }
            }
        }
        for ( String x : result ) {
            Matcher m = emailPattern.matcher ( x );
            if ( !m.matches() ) {
                invalidAddresses.add ( x );
            } else {
                validAddresses.add ( x );
            }
        }
        result = new String[validAddresses.size()];
        Iterator<String> i = validAddresses.iterator();
        j = 0;
        while ( i.hasNext() ) {
            result[j] = i.next();
            j++;
        }
        return result;
    }
    private static int getAnzahlAdressen ( String a, char s ) {
        int result = 1;
        for ( int i = 0; i < a.length(); i++ )
            if ( a.charAt ( i ) == s ) {
                result++;
            }
        return result;
    }
}
