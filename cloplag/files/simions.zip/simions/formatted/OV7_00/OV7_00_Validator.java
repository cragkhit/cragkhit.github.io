import java.util.ArrayList;
import java.util.Set;
import java.util.regex.Pattern;
public class OV7_00_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        String[] result = new String[0];
        if ( addresses == null ) {
            return result;
        }
        ArrayList<String> validAddresses = new ArrayList<String>();
        addresses += separator;
        while ( addresses.indexOf ( separator ) != -1 ) {
            int nextSeparator = addresses.indexOf ( separator );
            String currentAddress = addresses.substring ( 0, nextSeparator );
            if ( currentAddress.length() > 0 ) {
                if ( emailPattern.matcher ( currentAddress ).matches() ) {
                    validAddresses.add ( currentAddress );
                } else {
                    invalidAddresses.add ( currentAddress );
                }
            }
            addresses = addresses.substring ( ++nextSeparator );
        }
        return validAddresses.toArray ( result );
    }
}
