import java.util.ArrayList;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
public class I3_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.length() == 0 ) {
            return new String[0];
        }
        StringTokenizer t = new StringTokenizer ( addresses, Character.toString ( separator ) );
        ArrayList<String> valid = new ArrayList<String>();
        String cAddress;
        while ( t.hasMoreTokens() ) {
            cAddress = t.nextToken();
            if ( cAddress.matches ( emailPattern.toString() ) ) {
                valid.add ( cAddress );
            } else {
                invalidAddresses.add ( cAddress );
            }
        }
        return valid.toArray ( new String[valid.size()] );
    }
}
