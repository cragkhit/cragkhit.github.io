import java.util.*;
import java.util.regex.*;
public class F3_02_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null ) {
            return new String[0];
        }
        ArrayList<String> validAddresses = new ArrayList<String>();
        String one_address = "";
        for ( int i = 0; i < addresses.length(); i++ ) {
            if ( ( addresses.charAt ( i ) == separator ) || i + 1 == addresses.length() ) {
                if ( i + 1 == addresses.length() ) {
                    one_address += addresses.charAt ( i );
                }
                Matcher m = emailPattern.matcher ( one_address.trim() );
                if ( m.matches() ) {
                    validAddresses.add ( one_address );
                } else {
                    invalidAddresses.add ( one_address );
                }
                one_address = "";
            } else {
                one_address += addresses.charAt ( i );
            }
        }
        return validAddresses.toArray ( new String[0] );
    }
}
