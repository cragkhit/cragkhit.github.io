import java.util.Set;
import java.util.regex.Pattern;
public class FN2_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        int zahl = 0;
        if ( addresses == null || addresses.isEmpty() ) {
            return new String[0];
        }
        String[]validEmailAddresses = new String[addresses.length() / 5];
        String Ads = addresses;
        Ads = Ads + separator;
        while ( !Ads.isEmpty() ) {
            String Email = Ads.substring ( 0, Ads.indexOf ( separator ) );
            if ( emailPattern.matcher ( Email ).matches() ) {
                validEmailAddresses[zahl] = Email;
                zahl = zahl + 1;
            } else {
                invalidAddresses.add ( Email );
            }
            Ads = Ads.substring ( Ads.indexOf ( separator ) + 1 );
        }
        int count = 0;
        for ( int i = 0; i < validEmailAddresses.length; i++ )
            if ( validEmailAddresses[i] == null ) {
                break;
            } else {
                count++;
            }
        String[] result = new String[count];
        for ( int j = 0; j < count ; j++ ) {
            result[j] = validEmailAddresses[j];
        }
        return result;
    }
}
