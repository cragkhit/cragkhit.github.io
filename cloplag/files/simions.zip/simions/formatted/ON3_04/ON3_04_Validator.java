import java.util.Set;
import java.util.regex.Pattern;
public class ON3_04_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null ||  addresses == "" ) {
            return new String[0];
        }
        String separatorString = "";
        if ( separator == '\\' ) {
            separatorString = "\\\\";
        } else {
            separatorString = Character.toString ( separator );
        }
        String[] EmailAddresses = addresses.split ( separatorString );
        String validAddresses = "";
        for ( int i = 0; i < EmailAddresses.length; i++ ) {
            if ( Pattern.matches ( emailPattern.toString(), EmailAddresses[i] ) ) {
                validAddresses = validAddresses + EmailAddresses[i] + ";";
            } else if ( EmailAddresses[i] != null || EmailAddresses[i] != "" ) {
                invalidAddresses.add ( EmailAddresses[i] );
            }
        }
        if ( validAddresses == "" ) {
            return new String[0];
        } else {
            return validAddresses.split ( ";" );
        }
    }
}
