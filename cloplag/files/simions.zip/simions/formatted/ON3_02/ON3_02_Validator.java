import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class ON3_02_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        System.out.println ( "Aufruf" );
        System.out.println ( addresses );
        if ( addresses == null ) {
            return new String[0];
        }
        addresses = addresses.trim();
        ArrayList<String> validAddresses = new ArrayList<String>();
        System.out.println ( separator );
        String[] adressen;
        if ( separator == '\\' ) {
            adressen = addresses.split ( "\\\\" );
        } else {
            adressen = addresses.split ( Character.toString ( separator ) );
        }
        for ( int i = 0; i < adressen.length; i++ ) {
            adressen[i] = adressen[i].trim();
            if ( emailPattern.matcher ( adressen[i] ).matches() ) {
                validAddresses.add ( adressen[i] );
            } else if ( !adressen[i].isEmpty() ) {
                invalidAddresses.add ( adressen[i] );
            }
        }
        System.out.println ( validAddresses.toString() );
        System.out.println();
        return validAddresses.toArray ( new String[0] );
    }
}
