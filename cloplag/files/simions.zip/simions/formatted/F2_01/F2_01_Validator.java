import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class F2_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        System.out.println ( "Starting test:" );
        if ( addresses == null || addresses.length() == 0 ) {
            System.out.println ( " Invalid input String" );
            String[] result = new String[0];
            return result;
        }
        String workstr = addresses;
        System.out.println ( " Received String: " + workstr );
        ArrayList<String>  validAddresses = new ArrayList();
        for ( int i = 0; i < workstr.length(); i++ ) {
            if ( workstr.charAt ( i ) == separator ) {
                String oneMail = workstr.substring ( 0, i );
                cut ( oneMail );
                System.out.println ( "  Testing: " + oneMail );
                if ( emailPattern.matcher ( oneMail ).matches() ) {
                    validAddresses.add ( oneMail );
                    System.out.println ( "   -> valid" );
                } else {
                    invalidAddresses.add ( oneMail );
                    System.out.println ( "   -> invalid" );
                }
                workstr = workstr.substring ( i + 1, workstr.length() );
                i = 0;
            }
        }
        cut ( workstr );
        System.out.println ( " Reached end, so testing last address: " + workstr );
        if ( emailPattern.matcher ( workstr ).matches() ) {
            validAddresses.add ( workstr );
            System.out.println ( "  -> valid" );
        } else {
            invalidAddresses.add ( workstr );
            System.out.println ( "  -> invalid" );
        }
        return validAddresses.toArray ( new String[] {} );
    }
    void cut ( String mail2 ) {
        while ( mail2.charAt ( 0 ) == ' ' ) {
            mail2 = mail2.substring ( 1, mail2.length() - 1 );
        }
        while ( mail2.charAt ( mail2.length() - 1 ) == ' ' ) {
            mail2 = mail2.substring ( 0, mail2.length() - 2 );
        }
    }
}
