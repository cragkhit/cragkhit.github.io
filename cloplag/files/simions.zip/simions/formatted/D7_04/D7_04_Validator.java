import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class D7_04_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        String[] addressList;
        ArrayList<String> liste = new ArrayList<String>();
        if ( addresses == "" || separator + "" == "" || addresses == null ) {
            return new String[] {};
        } else {
            addressList = addresses.split ( "\\" + separator + "" );
            for ( String curEmailAddress : addressList ) {
                curEmailAddress.replaceAll ( " ", "" );
                if ( curEmailAddress == "" || curEmailAddress == null ) {
                    return new String[] {};
                } else if ( isValidEmailAddress ( curEmailAddress ) ) {
                    liste.add ( curEmailAddress );
                } else {
                    invalidAddresses.add ( curEmailAddress );
                }
            }
        }
        return liste.toArray ( new String[] {} );
    }
    public boolean isValidEmailAddress ( String address ) {
        return emailPattern.matcher ( address ).matches();
    }
    public static Iterable<MatchResult> findMatches ( Pattern pattern, CharSequence s ) {
        List<MatchResult> results = new ArrayList<MatchResult>();
        for ( Matcher m = pattern.matcher ( s ); m.find(); ) {
            results.add ( m.toMatchResult() );
        }
        return results;
    }
}
