import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.Set;
import java.util.HashSet;
import java.util.regex.Pattern;
public class OV06_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses == "" ) {
            return new String[0];
        }
        if ( invalidAddresses == null ) {
            invalidAddresses = new HashSet<String>();
        }
        Stack<String> os = new Stack<String>();
        boolean escape_separator = false;
        if ( ( "[\\'()?!$\"" ).contains ( "" + separator ) ) {
            escape_separator = true;
        }
        String[] adress_list = addresses.split ( "[\\s]?" + ( escape_separator ? "\\" : "" ) + separator + "[\\s]?" );
        for ( String s : adress_list )
            if ( ( emailPattern.matcher ( s ) ).matches() ) {
                os.push ( s );
            } else {
                invalidAddresses.add ( s );
            }
        String[] oa = new String[os.size()];
        os.toArray ( oa );
        return oa;
    }
}
