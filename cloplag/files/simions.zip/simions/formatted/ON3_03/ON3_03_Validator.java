import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class ON3_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        String checkstring;
        int i;
        String[] estring = new String[0];
        if ( addresses == null || addresses.isEmpty() ) {
            return estring;
        }
        String[] retstring = new String[1];
        int strpoint = 0;
        while ( addresses.length() > 0 ) {
            if ( !addresses.contains ( Character.toString ( separator ) ) ) {
                checkstring = addresses;
                addresses = "";
            } else {
                checkstring = setString ( addresses, Character.toString ( separator ) );
                i = addresses.indexOf ( separator );
                addresses = addresses.substring ( i + 1 );
            }
            if ( validateSingle ( checkstring ) ) {
                if ( strpoint >= retstring.length ) {
                    retstring = doubleCapacity ( retstring );
                }
                retstring[strpoint] = checkstring;
                strpoint++;
            } else {
                if ( ! ( invalidAddresses == null ) ) {
                    invalidAddresses.add ( checkstring );
                }
            }
        }
        if ( strpoint == 0 ) {
            return estring;
        }
        return retstring;
    }
    private String setString ( String list, String separato ) {
        int i = list.indexOf ( separato );
        if ( i > 0 ) {
            return list.substring ( 0, i );
        } else {
            return "";
        }
    }
    private boolean validateSingle ( String address ) {
        if ( address.isEmpty() ) {
            return false;
        }
        while ( address.charAt ( 0 ) == ' ' ) {
            address = address.substring ( 1 );
        }
        while ( address.charAt ( address.length() - 1 ) == ' ' ) {
            address = address.substring ( 0, address.length() - 2 );
        }
        if ( !address.contains ( "@" ) || !address.contains ( "." ) ) {
            return false;
        }
        if ( address.codePointAt ( 0 ) == '@' || address.codePointAt ( address.length() - 1 ) == '.' || address.codePointAt ( address.length() - 1 ) == '@' ) {
            return false;
        }
        address = address.substring ( 1 );
        while ( address.codePointAt ( 0 ) != '@' ) {
            if ( ! ( address.codePointAt ( 0 ) == '.' || ( address.codePointAt ( 0 ) >= 97 && address.codePointAt ( 0 ) <= 122 ) || ( address.codePointAt ( 0 ) >= 48 && address.codePointAt ( 0 ) <= 57 ) || ( address.codePointAt ( 0 ) >= 65 && address.codePointAt ( 0 ) <= 90 ) ) ) {
                return false;
            }
            address = address.substring ( 1 );
        }
        address = address.substring ( 1 );
        boolean contPoint = false;
        while ( !address.isEmpty() ) {
            if ( ! ( address.codePointAt ( 0 ) == '.' || ( address.codePointAt ( 0 ) >= 97 && address.codePointAt ( 0 ) <= 122 ) || ( address.codePointAt ( 0 ) >= 48 && address.codePointAt ( 0 ) <= 57 ) || ( address.codePointAt ( 0 ) >= 65 && address.codePointAt ( 0 ) <= 90 ) ) ) {
                return false;
            }
            if ( address.codePointAt ( 0 ) == '.' ) {
                contPoint = true;
            }
            address = address.substring ( 1 );
        }
        if ( contPoint ) {
            return true;
        } else {
            return false;
        }
    }
    private String[] doubleCapacity ( String[] s ) {
        String[] b = new String[2 * s.length] ;
        for ( int i = 0; i < s.length; i++ ) {
            b[i] = s[i];
        }
        return b;
    }
}
