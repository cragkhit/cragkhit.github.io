import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class D4_06_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == ( null ) || addresses.isEmpty() ) {
            System.out.println ( "keine richtige e-Mailadresse" );
            return new String[] {};
        }
        else {
            return validate ( addresses, separator, invalidAddresses );
        }
    }
    public String[] validate ( String addresses, char separator, Set<String> invalidAddresses ) {
        int x = 0;
        List<String> result = new ArrayList<String>();
        String[] adrArray = addresses.split ( "\\s*" + separator + "\\s*" );
        for ( String adr : adrArray ) {
            if ( emailPattern.matcher ( adr ).matches() ) {
                result.add ( adr );
            } else {
                invalidAddresses.add ( adr );
            }
        }
        return result.toArray ( new String[] {} );
    }
}
