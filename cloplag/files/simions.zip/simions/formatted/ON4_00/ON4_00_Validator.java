import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class ON4_00_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        String[] addressesArr = new String[0];
        String splitter = String.valueOf ( separator );
        int invalidFilteredAddresses = 0;
        if ( addresses == null || addresses == "" ) {
            return addressesArr;
        } else {
            addressesArr = addresses.split ( "\\" + splitter );
            for ( int i = 0; i < addressesArr.length; i++ ) {
                Matcher m = emailPattern.matcher ( addressesArr[i] );
                boolean validEmail = m.matches();
                if ( !validEmail ) {
                    invalidAddresses.add ( addressesArr[i] );
                    addressesArr[i] = null;
                    invalidFilteredAddresses++;
                } else {}
            }
            String[] FilteredEmailAddresses = new String[ ( ( addressesArr.length ) - ( invalidFilteredAddresses ) )];
            int z = 0;
            int w = 0;
            while ( z < FilteredEmailAddresses.length ) {
                if ( addressesArr[w] != null ) {
                    FilteredEmailAddresses[z] = addressesArr[z];
                    z++;
                    w++;
                } else {
                    w++;
                }
            }
            return FilteredEmailAddresses;
        }
    }
}
