import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Pattern;
public class D2_02_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        String validAddresses = "";
        Scanner address = new Scanner ( addresses == null ? "" : addresses );
        address.useDelimiter ( Pattern.compile ( " *" + Pattern.quote ( String.valueOf ( separator ) ) + " *" ) );
        while ( address.hasNext() ) {
            if ( address.hasNext ( emailPattern ) ) {
                validAddresses += address.next ( emailPattern ) + ":";
            } else {
                invalidAddresses.add ( address.next() );
            }
        }
        if ( validAddresses.length() == 0 ) {
            validAddresses = ":";
        }
        return validAddresses.split ( ":" );
    }
}
