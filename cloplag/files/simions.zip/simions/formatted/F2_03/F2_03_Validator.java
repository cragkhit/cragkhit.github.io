import java.util.ArrayList;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
public class F2_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.isEmpty() ) {
            return new String[0];
        }
        StringTokenizer addr = new StringTokenizer ( addresses, "" + separator );
        String email;
        ArrayList<String> validAddresses = new ArrayList<String>();
        while ( addr.hasMoreTokens() ) {
            email = addr.nextToken();
            if ( emailPattern.matcher ( email ).matches() ) {
                validAddresses.add ( email );
            } else {
                invalidAddresses.add ( email );
            }
        }
        return validAddresses.toArray ( new String[validAddresses.size()] );
    }
}
