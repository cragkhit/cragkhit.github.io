import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class M2_05_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        if ( ( addresses == null ) || ( addresses == "" ) ) return new String[] {};
        ArrayList<String> result =  new ArrayList();
        if ( separator == '\\' ) {
            addresses = addresses.replace ( separator, ',' );
            separator = ',';
        }
        String[] _Email = addresses.split ( Character.toString ( separator ) );
        for ( int i = 0; i < _Email.length; i++ ) {
            if ( isValid ( _Email[i] ) ) {
                result.add ( _Email[i] );
            } else {
                invalidAddresses.add ( _Email[i] );
            }
        }
        return result.toArray ( new String[] {} );
    }
    public boolean isValid ( String address ) {
        return emailPattern.matches ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+", address );
    }
}
