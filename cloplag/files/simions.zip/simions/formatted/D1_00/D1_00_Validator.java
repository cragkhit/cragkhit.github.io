import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class D1_00_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.isEmpty() ) {
            return	new String[] {};
        } else {
            String sep = "" + separator;
            List<String> list = new ArrayList<String>();
            StringTokenizer st = new StringTokenizer ( addresses, sep );
            Matcher m;
            while ( st.hasMoreTokens() ) {
                String nextToken = st.nextToken();
                System.out.println ( nextToken );
                if ( nextToken.startsWith ( " " ) ) {
                    nextToken = nextToken.substring ( 1 ) ;
                }
                if ( nextToken.endsWith ( " " ) ) {
                    nextToken = nextToken.substring ( 0, nextToken.length() - 1 );
                }
                System.out.println ( nextToken );
                m = emailPattern.matcher ( nextToken );
                if ( m.matches() ) {
                    list.add ( nextToken );
                } else {
                    invalidAddresses.add ( nextToken );
                }
            }
            String [] s = new String[] {};
            return list.toArray ( s );
        }
    }
}
