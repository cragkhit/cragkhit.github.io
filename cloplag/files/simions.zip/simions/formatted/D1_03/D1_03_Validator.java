import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class D1_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.length() == 0 ) return new String[] {};
        String strSeparator;
        if ( separator == '\\' ) {
            strSeparator = "\\\\";
        } else {
            strSeparator = String.valueOf ( separator );
        }
        String[] addressArray = addresses.split ( "[ ]*" + strSeparator + "[ ]*" );
        List<String> valid = new ArrayList<String>();
        for ( String address : addressArray ) {
            if ( address != "" ) {
                Matcher m = emailPattern.matcher ( address );
                if ( m.matches() ) {
                    valid.add ( address );
                } else {
                    invalidAddresses.add ( address );
                }
            }
        }
        return valid.toArray ( new String[] {} );
    }
}
