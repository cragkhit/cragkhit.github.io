import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.StringTokenizer;
public class D4_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.equals ( "" ) ) {
            return new String[0];
        } else {
            addresses.replace ( " ", "" );
            ArrayList<String> valid_addresses = new ArrayList<String>();
            StringTokenizer tokenizer = new StringTokenizer ( addresses, String.valueOf ( separator ) );
            while ( tokenizer.hasMoreTokens() ) {
                String i = tokenizer.nextToken();
                if ( this.emailPattern.matcher ( i ).matches() ) {
                    valid_addresses.add ( i );
                } else {
                    invalidAddresses.add ( i );
                }
            }
            return valid_addresses.toArray ( new String[0] );
        }
    }
}
