import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class D8_00_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null ) {
            return new String[0];
        }
        if ( addresses.length() == 0 ) {
            return new String[0];
        }
        String sep;
        if ( separator != '\\' ) {
            sep = String.valueOf ( separator );
        } else {
            sep = "\\\\";
        }
        ArrayList<String> validAddresses = new ArrayList<String>();
        String[] possibleAddresses = addresses.split ( sep );
        for ( String address : possibleAddresses ) {
            Matcher matcher = emailPattern.matcher ( address.subSequence ( 0, address.length() ) );
            if ( matcher.matches() ) {
                validAddresses.add ( address );
            } else {
                invalidAddresses.add ( address );
            }
        }
        return validAddresses.toArray ( new String[0] );
    }
}
