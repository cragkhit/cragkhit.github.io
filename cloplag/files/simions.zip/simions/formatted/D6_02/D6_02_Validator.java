import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.StringTokenizer;
public class D6_02_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || invalidAddresses == null || addresses.trim() == "" ) {
            return new String[0];
        }
        StringTokenizer st = new StringTokenizer ( addresses, String.valueOf ( separator ) );
        List<String> validAddresses = new ArrayList<String>();
        while ( st.hasMoreTokens() ) {
            String currentAddress = st.nextToken().trim();
            if ( emailPattern.matcher ( currentAddress ).matches() ) {
                validAddresses.add ( currentAddress );
            } else {
                invalidAddresses.add ( currentAddress );
            }
        }
        return validAddresses.toArray ( new String[validAddresses.size()] );
    }
}
