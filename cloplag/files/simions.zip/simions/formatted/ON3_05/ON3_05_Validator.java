import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class ON3_05_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.length() == 0 ) {
            return new String[0];
        }
        ArrayList<String> parsed = this.parseAddresses ( addresses, separator );
        ArrayList<String> matching = new ArrayList<String>();
        Iterator<String> parsedIterator = parsed.iterator();
        while ( parsedIterator.hasNext() ) {
            String address = parsedIterator.next();
            Matcher addressMatcher = this.emailPattern.matcher ( address );
            if ( addressMatcher.matches() ) {
                matching.add ( address );
                System.out.println ( address );
            } else {
                invalidAddresses.add ( address );
            }
        }
        String[] result = new String[matching.size()];
        int index = 0;
        for ( String element : matching ) {
            result[index++] = new String ( element );
        }
        return result;
    }
    private ArrayList<String> parseAddresses ( String addresses, char separator ) {
        char[] addressesArray = addresses.toCharArray();
        ArrayList<String> parsed = new ArrayList<String>();
        int previousIndex = 0;
        System.out.println ( addresses );
        for ( int i = 0; i < addressesArray.length; i++ ) {
            if ( addressesArray[i] == separator ) {
                parsed.add ( addresses.substring ( previousIndex, i ).trim() );
                previousIndex = i + 1;
            }
            if ( i == addressesArray.length - 1 ) {
                parsed.add ( addresses.substring ( previousIndex, i + 1 ).trim() );
            }
        }
        return parsed;
    }
}
