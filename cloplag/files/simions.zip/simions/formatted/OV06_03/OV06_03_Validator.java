import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class OV06_03_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        String[] tmp;
        String[] result = new String[0];
        String s_sep;
        if ( ( addresses != null ) && !addresses.isEmpty() ) {
            s_sep = Character.toString ( separator );
            addresses.replaceAll ( " ", "" );
            if ( separator == '\\' ) {
                s_sep = "\\\\";
            }
            tmp = addresses.split ( s_sep );
            for ( String s : tmp ) {
                Matcher matcher = emailPattern.matcher ( s );
                if ( matcher.matches() ) {
                    result = appendArray ( result, s );
                } else {
                    invalidAddresses.add ( s );
                }
            }
        }
        return result;
    }
    public String[] appendArray ( String[] array, String element ) {
        String[] result = new String[array.length + 1];
        int i = 0;
        for ( String s : array ) {
            result[i] = s;
            i++;
        }
        result[i] = element;
        return result;
    }
}
