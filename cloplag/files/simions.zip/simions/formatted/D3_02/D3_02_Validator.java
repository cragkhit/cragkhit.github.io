import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.*;
public class D3_02_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.isEmpty() ) {
            return new String[] {};
        }
        String[] sepaAddresses =  new String[addresses.length() + 1];
        List<String> valAddresses = new ArrayList<String>();
        List<String> sepAddresses = new ArrayList<String>();
        sepaAddresses = addresses.split ( Pattern.quote ( String.valueOf ( separator ) ) );
        for ( int i = 0; i < sepaAddresses.length ; i++ ) {
            sepAddresses.add ( sepaAddresses[i] );
        }
        while ( !sepAddresses.isEmpty() ) {
            try {
                String tmp = sepAddresses.get ( 0 );
                Matcher m = emailPattern.matcher ( tmp );
                if ( m.matches() ) {
                    valAddresses.add ( tmp );
                    sepAddresses.remove ( 0 );
                } else {
                    invalidAddresses.add ( tmp );
                    sepAddresses.remove ( 0 );
                }
            } catch ( Exception ex ) {
                ex.printStackTrace();
            }
        }
        String[] result = new String[valAddresses.size()];
        for ( int k = 0; k < valAddresses.size(); k++ ) {
            result[k] = valAddresses.get ( k );
        }
        return result;
    }
}
