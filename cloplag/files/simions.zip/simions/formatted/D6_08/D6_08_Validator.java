import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.lang.String;
public class D6_08_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        List<String> validatedAddresses = new ArrayList<String>();
        if ( addresses == null ) return  new String[] {};
        if ( addresses.isEmpty() ) return new String[] {};
        String[] extractedAddresses;
        String separatorString = "" + separator;
        separatorString = Pattern.quote ( separatorString );
        extractedAddresses = addresses.split ( Pattern.quote ( "" + separator ) );
        for ( int i = 0; i < extractedAddresses.length; i++ ) {
            extractedAddresses[i] = extractedAddresses[i].trim();
            Matcher validate = emailPattern.matcher ( extractedAddresses[i] );
            if ( validate.matches() ) {
                validatedAddresses.add ( extractedAddresses[i] );
            } else {
                invalidAddresses.add ( extractedAddresses[i] );
            }
        }
        return validatedAddresses.toArray ( new String[0] );
    }
}
