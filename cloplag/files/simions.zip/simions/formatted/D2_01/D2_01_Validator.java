import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class D2_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        System.out.println ( addresses );
        try {
            if ( addresses.isEmpty() ) {
                return new String[0];
            }
        } catch ( NullPointerException e ) {
            return new String[0];
        }
        ArrayList<String> input = new ArrayList<String>();
        ArrayList<String> result = new ArrayList<String>();
        int index;
        String s = "";
        while ( addresses.charAt ( 0 ) == ( ' ' ) ) {
            addresses = addresses.substring ( 1, addresses.length() - 1 );
        }
        while ( ( index = addresses.indexOf ( separator ) ) != -1 ) {
            s = addresses.substring ( 0, index );
            while ( s.charAt ( s.length() - 1 ) == ' ' ) {
                s = s.substring ( 0, s.length() - 1 );
            }
            input.add ( s );
            addresses = addresses.substring ( index + 1, addresses.length() );
            while ( addresses.charAt ( 0 ) == ( ' ' ) ) {
                addresses = addresses.substring ( 1, addresses.length() );
            }
        }
        s = addresses.substring ( 0, addresses.length() );
        while ( s.charAt ( s.length() - 1 ) == ' ' ) {
            s = s.substring ( 0, s.length() - 1 );
        }
        input.add ( s );
        Iterator<String> it = input.iterator();
        while ( it.hasNext() ) {
            String adr = it.next();
            if ( pruefe ( adr ) ) {
                result.add ( adr );
            } else {
                invalidAddresses.add ( adr );
            }
        }
        String [] res = new String[0];
        res = result.toArray ( res );
        return res;
    }
    private boolean pruefe ( String ad ) {
        Matcher m = emailPattern.matcher ( ad );
        boolean b = m.matches();
        return b;
    }
}
