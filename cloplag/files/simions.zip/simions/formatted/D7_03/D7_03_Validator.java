import java.util.ArrayList;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
public class D7_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        if ( addresses == null || invalidAddresses == null ) {
            return new String[0];
        }
        ArrayList<String> validEmails = new ArrayList<String>();
        StringTokenizer st = new StringTokenizer ( addresses, Character.toString ( separator ) );
        while ( st.hasMoreTokens() ) {
            String tmp = st.nextToken();
            if ( emailPattern.matcher ( tmp ).matches() ) {
                validEmails.add ( tmp );
            } else {
                invalidAddresses.add ( tmp );
            }
        }
        return validEmails.toArray ( new String[validEmails.size()] );
    }
}
