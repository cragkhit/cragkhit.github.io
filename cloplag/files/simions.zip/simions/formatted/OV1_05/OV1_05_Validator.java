import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
public class OV1_05_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        ArrayList ValidAddresses = new ArrayList<String>();
        String currentAddress;
        if ( addresses == null ) {
            return new String[0];
        }
        if ( addresses == "" ) {
            return new String[0];
        }
        String[] AllAddresses = addresses.split ( Pattern.quote ( Character.toString ( separator ) ) );
        for ( int i = 0; i <= AllAddresses.length - 1; i++ ) {
            currentAddress = AllAddresses[i].trim();
            if ( emailPattern.matcher ( currentAddress ).matches() ) {
                ValidAddresses.add ( currentAddress );
            } else {
                invalidAddresses.add ( currentAddress );
            }
        }
        return ( String[] ) ValidAddresses.toArray ( new String[0] );
    }
}
