import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
public class M2_01_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null ) {
            return new String[0];
        }
        List<String> validAddresses = new ArrayList<String>();
        StringTokenizer addressTokens = new StringTokenizer ( addresses, String.valueOf ( separator ) );
        while ( addressTokens.hasMoreElements() ) {
            String address = addressTokens.nextToken();
            if ( emailPattern.matcher ( address ).matches() ) {
                validAddresses.add ( address );
            } else {
                invalidAddresses.add ( address );
            }
        }
        return validAddresses.toArray ( new String[0] );
    }
}
