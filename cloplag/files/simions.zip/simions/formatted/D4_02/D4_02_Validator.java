import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class D4_02_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.equals ( "" ) ) return new String[] {};
        String[] splittedAddresses = addresses.split ( "\\" + String.valueOf ( separator ) );
        List<String> tempValidAddresses = new ArrayList<String>();
        Matcher m;
        for ( String address : splittedAddresses ) {
            String trimmedAddress = address.trim();
            m = emailPattern.matcher ( trimmedAddress );
            if ( m.matches() ) {
                tempValidAddresses.add ( address );
            } else {
                invalidAddresses.add ( trimmedAddress );
            }
        }
        String[] validAddresses = new String[tempValidAddresses.size()];
        for ( int i = 0; i < tempValidAddresses.size(); i++ ) {
            validAddresses[i] = tempValidAddresses.get ( i );
        }
        return validAddresses;
    }
}
