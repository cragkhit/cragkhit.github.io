import java.util.ArrayList;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class D4_05_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        if ( addresses == null || addresses == "" ) {
            return new String[0];
        }
        ArrayList<String> rAddresses = new ArrayList<String>();
        String[] possibles = addresses.split ( "w*" + ( separator == '\\' ? "\\\\" : separator ) + "w*" );
        for ( String candidate : possibles ) {
            Matcher matcher = emailPattern.matcher ( candidate );
            if ( matcher.matches() ) {
                rAddresses.add ( candidate );
            } else {
                invalidAddresses.add ( candidate );
            }
        }
        return rAddresses.toArray ( new String[rAddresses.size()] );
    }
}
