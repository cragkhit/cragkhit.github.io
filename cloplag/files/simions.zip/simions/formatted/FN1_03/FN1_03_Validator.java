import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class FN1_03_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        if ( addresses == null ) {
            return new String[0];
        }
        List<String> addressList = new ArrayList();
        List<String> validAddresses = new ArrayList();
        int index = addresses.indexOf ( separator );
        int pointer = 0;
        while ( index != -1 ) {
            addressList.add ( addresses.substring ( pointer, index ) );
            addressList.get ( addressList.size() - 1 ).trim();
            pointer = index + 1;
            index = addresses.indexOf ( separator, pointer );
        }
        if ( pointer < addresses.length() ) {
            addressList.add ( addresses.substring ( pointer ) );
            addressList.get ( addressList.size() - 1 ).trim();
        }
        Iterator<String> it = addressList.iterator();
        String next;
        Matcher m;
        while ( it.hasNext() ) {
            next = it.next();
            m = emailPattern.matcher ( next );
            if ( m.matches() ) {
                validAddresses.add ( next );
            } else {
                invalidAddresses.add ( next );
            }
        }
        return validAddresses.toArray ( new String[0] );
    }
}
