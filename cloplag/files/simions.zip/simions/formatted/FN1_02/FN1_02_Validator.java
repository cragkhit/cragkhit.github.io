import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class FN1_02_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        if ( addresses == null || addresses.length() < 1 )
            return new String[] {};
        List<String> validMails = new ArrayList<String>();
        String[] valid = new String[] {};
        String[] mails = addresses.split ( "\\s*" + separator + "\\s*" );
        Matcher matcher = null;
        for ( int i = 0; i < mails.length; i++ ) {
            matcher = emailPattern.matcher ( mails[i] );
            if ( matcher.matches() ) {
                validMails.add ( mails[i] );
            } else {
                invalidAddresses.add ( mails[i] );
            }
        }
        return validMails.toArray ( valid );
    }
}
