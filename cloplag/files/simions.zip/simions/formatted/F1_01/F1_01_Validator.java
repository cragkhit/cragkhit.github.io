import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class F1_01_Validator {
    private final Pattern emailPattern = Pattern.compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator, Set<String> invalidAddresses ) {
        ArrayList<String> validAddresses = new ArrayList<String>();
        if ( addresses == null || addresses.equals ( "" ) )
            return new String[] {};
        else {
            String[] adressesList = addresses.split ( "\\" + separator );
            for ( String address : adressesList ) {
                address = address.trim();
                Matcher m = emailPattern.matcher ( address );
                if ( m.matches() ) {
                    validAddresses.add ( address );
                } else {
                    invalidAddresses.add ( address );
                }
            }
            return validAddresses.toArray ( new String[0] );
        }
    }
}
