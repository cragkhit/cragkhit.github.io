import java.util.ArrayList;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Pattern;
public class D6_04_Validator {
    private final Pattern emailPattern = Pattern
                                         .compile ( "[.A-Za-z0-9]+@[.A-Za-z0-9]+[.][A-Za-z]+" );
    public String[] validateEmailAddresses ( String addresses, char separator,
            Set<String> invalidAddresses ) {
        ArrayList<String> result = new ArrayList<String>();
        StringTokenizer token = null;
        try {
            token = new StringTokenizer ( addresses, Character.toString ( separator ) );
        } catch ( NullPointerException npe ) {
            System.out.println ( "Found null-reference at addresses" );
        }
        while ( token != null && token.hasMoreTokens() ) {
            String tmpAddress = token.nextToken().trim();
            if ( tmpAddress.matches ( emailPattern.toString() ) ) {
                result.add ( tmpAddress );
            } else {
                if ( !invalidAddresses.contains ( tmpAddress ) ) {
                    invalidAddresses.add ( tmpAddress );
                }
            }
        }
        return result.toArray ( new String[result.size()] );
    }
}
